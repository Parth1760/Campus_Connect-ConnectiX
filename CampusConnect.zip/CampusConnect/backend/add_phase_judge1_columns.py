from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE scores ADD COLUMN team_id INT NULL"))
    conn.commit()
print("team_id column added to scores!")

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE scores MODIFY registration_id INT NULL"))
    conn.commit()
print("registration_id made nullable in scores!")

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE scores ADD COLUMN innovation INT NULL"))
    conn.execute(text("ALTER TABLE scores ADD COLUMN technical_implementation INT NULL"))
    conn.execute(text("ALTER TABLE scores ADD COLUMN presentation INT NULL"))
    conn.execute(text("ALTER TABLE scores ADD COLUMN problem_solving INT NULL"))
    conn.commit()
print("criteria columns added to scores!")

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE scores ADD CONSTRAINT fk_score_team FOREIGN KEY (team_id) REFERENCES teams(id)"))
    conn.commit()
print("FK constraint added!")