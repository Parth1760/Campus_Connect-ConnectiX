from datetime import datetime, timezone
from app.database import SessionLocal
from app.models.user import User
from app.models.event import Event
from app.models.team import Team
from app.models.registration import Registration
from app.models.score import Score
from app.models.feedback import Feedback

db = SessionLocal()

students = db.query(User).filter(User.role == "student").order_by(User.id).all()
faculty = db.query(User).filter(User.role == "faculty").order_by(User.id).all()
judges = db.query(User).filter(User.role == "judge").order_by(User.id).all()
events = db.query(Event).order_by(Event.id).all()

if len(students) < 6 or len(events) < 15:
    print("Seed data not found! Run seed_data.py first.")
    exit()

event_by_title = {e.title: e for e in events}
now = datetime.now(timezone.utc)


def register_individual(event, student, status="approved", attended=False):
    existing = db.query(Registration).filter(Registration.event_id == event.id, Registration.user_id == student.id).first()
    if existing:
        return existing
    reg = Registration(event_id=event.id, user_id=student.id, status=status)
    if attended:
        reg.is_attended = True
        reg.checked_in_at = now
    db.add(reg)
    db.commit()
    db.refresh(reg)
    return reg


def register_team(event, team_name, members, status="approved", attended=False):
    team = db.query(Team).filter(Team.event_id == event.id, Team.team_name == team_name).first()
    if team:
        return team
    team = Team(event_id=event.id, team_name=team_name, created_by=members[0].id,
                project_idea=f"A project built for {event.title} by team {team_name}.")
    db.add(team)
    db.commit()
    db.refresh(team)

    for m in members:
        existing = db.query(Registration).filter(Registration.event_id == event.id, Registration.user_id == m.id).first()
        if existing:
            continue
        reg = Registration(event_id=event.id, user_id=m.id, team_id=team.id, status=status)
        if attended:
            reg.is_attended = True
            reg.checked_in_at = now
        db.add(reg)
    db.commit()
    return team


def score_team(event, team, judge, total_score, remarks="Good work overall."):
    existing = db.query(Score).filter(Score.team_id == team.id, Score.judge_id == judge.id).first()
    if existing:
        return
    quarter = total_score // 4
    remainder = total_score - (quarter * 4)
    score = Score(
        event_id=event.id, team_id=team.id, judge_id=judge.id,
        innovation=quarter + (1 if remainder > 0 else 0),
        technical_implementation=quarter + (1 if remainder > 1 else 0),
        presentation=quarter,
        problem_solving=quarter,
        score=total_score, remarks=remarks,
    )
    db.add(score)
    db.commit()


def add_feedback(event, student, rating, comment):
    existing = db.query(Feedback).filter(Feedback.event_id == event.id, Feedback.user_id == student.id).first()
    if existing:
        return
    db.add(Feedback(event_id=event.id, user_id=student.id, rating=rating, comment=comment))
    db.commit()


s = students  # shorthand, s[0]..s[5]

# ---------- Robotics Challenge: 3 teams, clean ranking demo ----------
robotics = event_by_title["Robotics Challenge 2026"]
t1 = register_team(robotics, "Dev Dynamos", [s[0], s[1]], attended=True)
t2 = register_team(robotics, "Neural Knights", [s[2], s[3]], attended=True)
t3 = register_team(robotics, "Pixel Perfect", [s[4], s[5]], attended=True)

score_team(robotics, t1, judges[0], 88, "Solid mechanical design, good execution.")
score_team(robotics, t1, judges[1], 84, "Strong build quality.")
score_team(robotics, t2, judges[0], 94, "Excellent autonomous navigation.")
score_team(robotics, t2, judges[1], 90, "Very well engineered.")
score_team(robotics, t3, judges[0], 76, "Good effort, needs refinement.")
score_team(robotics, t3, judges[1], 72, "Decent but incomplete.")

# ---------- AI Innovate Hackathon: score the already-seeded "Code Crusaders" team ----------
hackathon = event_by_title["AI Innovate Hackathon 2026"]
existing_team = db.query(Team).filter(Team.event_id == hackathon.id, Team.team_name == "Code Crusaders").first()
if existing_team:
    members = db.query(Registration).filter(Registration.team_id == existing_team.id).all()
    for r in members:
        r.is_attended = True
        r.checked_in_at = now
        r.status = "approved"
    db.commit()
    score_team(hackathon, existing_team, judges[2], 91, "Impressive AI recommendation engine.")
    score_team(hackathon, existing_team, judges[3], 87, "Great execution under time pressure.")

# individual registrants for AI Hackathon (already seeded) -> mark attended + approved
for reg in db.query(Registration).filter(Registration.event_id == hackathon.id, Registration.team_id.is_(None)).all():
    reg.is_attended = True
    reg.checked_in_at = now
    reg.status = "approved"
db.commit()

# ---------- Smart City Hack Fest: 1 team ----------
smart_city = event_by_title["Smart City Hack Fest"]
tsc = register_team(smart_city, "IoT Innovators", [s[0], s[2], s[4]], attended=True)
score_team(smart_city, tsc, judges[1], 82, "Solid IoT prototype.")

# ---------- Competitive Programming Contest: existing individual + 1 team ----------
contest = event_by_title["Competitive Programming Contest"]
reg = register_individual(contest, s[5], attended=True)
tcp = register_team(contest, "Code Ninjas", [s[0], s[3]], attended=True)
score_team(contest, tcp, judges[3], 79, "Fast problem solving.")

# ---------- Other team-enabled events: a few individual signups (no team formed) ----------
register_individual(event_by_title["FinTech Blockchain Hackathon"], s[1], attended=False)
register_individual(event_by_title["UI/UX Design Sprint"], s[4], status="pending")

# ---------- Individual events: Workshops / Seminars / Webinars ----------
individual_events = [
    "Flutter & Firebase Bootcamp", "Machine Learning with Python", "Cloud Computing with AWS",
    "Future of Artificial Intelligence", "Cybersecurity in the Digital Age", "Entrepreneurship & Startups",
    "Careers in Data Science", "Intro to Web3 & Blockchain", "Resume & Interview Prep",
]
attendees_pattern = [
    [s[0], s[1], s[2]], [s[1], s[3], s[4]], [s[0], s[2], s[5]],
    [s[2], s[3], s[4]], [s[0], s[5]], [s[1], s[2]],
    [s[3], s[4], s[5]], [s[0], s[1]], [s[2], s[4], s[5]],
]

for title, attendees in zip(individual_events, attendees_pattern):
    event = event_by_title[title]
    for i, student in enumerate(attendees):
        attended = i < len(attendees) - 1  # last one stays not-attended
        status = "pending" if (title == "Cybersecurity in the Digital Age" and student == attendees[0]) else "approved"
        register_individual(event, student, status=status, attended=attended)
        if attended:
            add_feedback(event, student, rating=[4, 5, 3, 5, 4][hash(f"{title}{student.id}") % 5],
                          comment="Really informative session, learned a lot!")

db.commit()

print("Activity simulation complete!")
print("- Robotics Challenge: 3 teams scored (clean 1st/2nd/3rd ranking)")
print("- AI Innovate Hackathon: 'Code Crusaders' scored + attended")
print("- Smart City Hack Fest, Competitive Programming Contest: teams scored")
print("- 9 individual events: registrations + attendance + feedback spread across students")
print("- A few registrations left 'pending' for Approve/Reject testing")