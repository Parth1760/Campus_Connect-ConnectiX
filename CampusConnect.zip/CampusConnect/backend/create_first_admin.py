from app.database import SessionLocal
from app.models.user import User
from app.utils.security import hash_password

db = SessionLocal()

admin = User(
    full_name="Super Admin",
    email="admin@admin.in",
    phone="9999999999",
    password=hash_password("Admin@123"),
    role="admin",
    is_active=True,
    is_verified=True,
)
db.add(admin)
db.commit()
print("First admin created! Email: admin@admin.in | Password: Admin@123")