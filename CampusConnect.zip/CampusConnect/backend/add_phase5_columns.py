from app.database import Base, engine
from app.models.user import User
from app.models.event import Event
from app.models.team import Team
from app.models.feedback import Feedback
from sqlalchemy import text

print("Creating feedbacks table...")
Base.metadata.create_all(bind=engine)

try:
    with engine.connect() as conn:
        conn.execute(text("ALTER TABLE registrations ADD COLUMN certificate_id VARCHAR(36) NULL UNIQUE"))
        conn.commit()
    print("certificate_id column added to registrations!")
except Exception as e:
    print(f"Note: {e}")

print("Done!")