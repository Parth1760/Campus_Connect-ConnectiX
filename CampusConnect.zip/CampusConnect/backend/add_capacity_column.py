from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE events ADD COLUMN max_participants INT NULL"))
    conn.commit()

print("Capacity column added successfully!")