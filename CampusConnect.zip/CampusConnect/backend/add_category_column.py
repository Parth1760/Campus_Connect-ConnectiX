from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE events ADD COLUMN category VARCHAR(30) NULL"))
    conn.commit()

print("Category column added successfully!")