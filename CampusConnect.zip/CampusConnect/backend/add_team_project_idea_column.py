from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE teams ADD COLUMN project_idea TEXT NULL"))
    conn.commit()

print("project_idea column added to teams!")