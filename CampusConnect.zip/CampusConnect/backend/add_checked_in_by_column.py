from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE registrations ADD COLUMN checked_in_by INT NULL"))
    conn.commit()

print("checked_in_by column added to registrations!")