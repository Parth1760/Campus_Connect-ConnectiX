from app.database import Base, engine
from app.models.user import User
from app.models.event import Event
from app.models.registration import Registration
from app.models.score import Score
from app.models.notification import Notification
from app.models.password_reset import PasswordReset
from app.models.email_verification import EmailVerification
from app.models.team import Team



print("Creating tables...")
Base.metadata.create_all(bind=engine)

print("Done!")
