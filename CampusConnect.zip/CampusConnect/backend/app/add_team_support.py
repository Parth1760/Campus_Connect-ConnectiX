from app.database import Base, engine
from app.models.user import User
from app.models.event import Event
from app.models.team import Team
from sqlalchemy import text

print("Creating teams table...")
Base.metadata.create_all(bind=engine)

try:
    with engine.connect() as conn:
        conn.execute(text("ALTER TABLE registrations ADD COLUMN team_id INT NULL"))
        conn.commit()
    print("team_id column added to registrations!")
except Exception as e:
    print(f"Note: {e}")

print("Done!")