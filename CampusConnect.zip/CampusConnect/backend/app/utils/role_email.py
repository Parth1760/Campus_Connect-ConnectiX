from fastapi import HTTPException

ROLE_EMAIL_SUFFIX = {
    "student": "@student.in",
    "faculty": "@faculty.in",
    "volunteer": "@volunteer.in",
    "judge": "@judge.in",
    "admin": "@admin.in",
}


def validate_email_for_role(email: str, role: str):
    suffix = ROLE_EMAIL_SUFFIX.get(role)
    if suffix and not email.lower().endswith(suffix):
        raise HTTPException(
            status_code=400,
            detail=f"{role.capitalize()} accounts must use an email ending with {suffix}"
        )