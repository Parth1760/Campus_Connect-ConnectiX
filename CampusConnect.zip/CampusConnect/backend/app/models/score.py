from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.sql import func

from app.database import Base


class Score(Base):
    __tablename__ = "scores"

    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    registration_id = Column(Integer, ForeignKey("registrations.id"), nullable=True)
    team_id = Column(Integer, ForeignKey("teams.id"), nullable=True)
    judge_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    score = Column(Float, nullable=False)
    innovation = Column(Integer, nullable=True)
    technical_implementation = Column(Integer, nullable=True)
    presentation = Column(Integer, nullable=True)
    problem_solving = Column(Integer, nullable=True)
    remarks = Column(String(500), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )