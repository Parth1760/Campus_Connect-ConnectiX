import uuid
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.sql import func

from app.database import Base


class Registration(Base):
    __tablename__ = "registrations"

    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    team_id = Column(Integer, ForeignKey("teams.id"), nullable=True)
    qr_code = Column(String(64), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    certificate_id = Column(String(36), unique=True, nullable=True)
    status = Column(String(20), nullable=False, default="pending")
    checked_in_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    is_attended = Column(Boolean, default=False)
    registered_at = Column(DateTime(timezone=True), server_default=func.now())
    checked_in_at = Column(DateTime(timezone=True), nullable=True)