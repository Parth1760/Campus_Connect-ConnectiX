from sqlalchemy import Column, Integer, String, Boolean

from app.database import Base


class SystemSettings(Base):
    __tablename__ = "system_settings"

    id = Column(Integer, primary_key=True, index=True)
    app_name = Column(String(100), default="CampusConnect")
    default_language = Column(String(50), default="English")
    timezone = Column(String(50), default="IST (UTC+5:30)")
    max_team_size = Column(Integer, default=4)
    registration_buffer_hours = Column(Integer, default=24)
    session_timeout_minutes = Column(Integer, default=60)
    two_factor_enabled = Column(Boolean, default=False)