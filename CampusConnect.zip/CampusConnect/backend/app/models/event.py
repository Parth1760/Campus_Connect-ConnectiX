from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey, Boolean
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.database import Base


class Event(Base):
    __tablename__ = "events"

    id = Column(Integer, primary_key=True, index=True)

    title = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    venue = Column(String(150), nullable=True)
    category = Column(String(30), nullable=True)
    max_participants = Column(Integer, nullable=True)
    allow_team_registration = Column(Boolean, default=True)
    banner_url = Column(String(500), nullable=True)
    event_date = Column(DateTime(timezone=True), nullable=False)

    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )