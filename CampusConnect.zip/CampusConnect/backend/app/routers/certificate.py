from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.certificate import CertificateResponse, CertificateVerifyResponse
from app.services.certificate_service import get_or_create_certificate, verify_certificate
from app.dependencies import get_current_user
from app.models.user import User

router = APIRouter(tags=["Certificates"])


@router.get("/events/{event_id}/certificate", response_model=CertificateResponse)
def get_certificate(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return get_or_create_certificate(db, event_id, current_user.id)


@router.get("/certificates/verify/{certificate_id}", response_model=CertificateVerifyResponse)
def verify(
    certificate_id: str,
    db: Session = Depends(get_db)
):
    return verify_certificate(db, certificate_id)