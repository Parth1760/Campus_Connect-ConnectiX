from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.score import ScoreCreate, ScoreResponse, ParticipantForJudging, LeaderboardEntry, TeamScoreCreate, TeamScoreResponse, TeamForJudging, TeamLeaderboardEntry, JudgeDashboardResponse
from app.services.score_service import get_participants_for_event, submit_score, get_leaderboard, get_teams_for_judging, submit_team_score, get_team_leaderboard, get_judge_dashboard
from app.dependencies import require_roles, get_current_user
from app.models.user import User
from typing import List




router = APIRouter(tags=["Judging"])


@router.get("/events/{event_id}/participants", response_model=List[ParticipantForJudging])
def list_participants(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("judge", "admin"))
):
    return get_participants_for_event(db, event_id, current_user.id)


@router.post("/events/{event_id}/score", response_model=ScoreResponse)
def score_participant(
    event_id: int,
    score_data: ScoreCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("judge", "admin"))
):
    return submit_score(db, event_id, current_user.id, score_data)


@router.get("/events/{event_id}/leaderboard", response_model=List[LeaderboardEntry])
def leaderboard(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return get_leaderboard(db, event_id)


@router.get("/judge/dashboard", response_model=JudgeDashboardResponse)
def judge_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("judge", "admin"))
):
    return get_judge_dashboard(db, current_user.id)


@router.get("/events/{event_id}/teams-for-judging", response_model=List[TeamForJudging])
def teams_for_judging(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("judge", "admin"))
):
    return get_teams_for_judging(db, event_id, current_user.id)


@router.post("/events/{event_id}/score-team", response_model=TeamScoreResponse)
def score_team(
    event_id: int,
    data: TeamScoreCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("judge", "admin"))
):
    return submit_team_score(db, event_id, current_user.id, data)


@router.get("/events/{event_id}/team-leaderboard", response_model=List[TeamLeaderboardEntry])
def team_leaderboard(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return get_team_leaderboard(db, event_id)