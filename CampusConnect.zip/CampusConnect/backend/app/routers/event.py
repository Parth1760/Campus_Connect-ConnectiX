from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.schemas.event import EventCreate, EventResponse, EventUpdate
from app.schemas.faculty import FacultyDashboardResponse, EventAnalyticsDetail
from app.services.event_service import create_event, get_all_events, get_event_by_id, update_event, delete_event, get_faculty_dashboard, get_event_analytics_detail
from app.dependencies import get_current_user, require_roles
from app.models.user import User

router = APIRouter(
    prefix="/events",
    tags=["Events"]
)


@router.post("/", response_model=EventResponse)
def add_event(
    event_data: EventCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return create_event(db, event_data, current_user.id)


@router.get("/", response_model=List[EventResponse])
def list_events(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return get_all_events(db)


@router.get("/faculty/dashboard", response_model=FacultyDashboardResponse)
def faculty_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return get_faculty_dashboard(db, current_user.id)


@router.get("/{event_id}", response_model=EventResponse)
def get_event(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    event = get_event_by_id(db, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event


@router.put("/{event_id}", response_model=EventResponse)
def edit_event(
    event_id: int,
    event_data: EventUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return update_event(db, event_id, event_data, current_user)


@router.delete("/{event_id}")
def remove_event(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return delete_event(db, event_id, current_user)

@router.get("/{event_id}/analytics", response_model=EventAnalyticsDetail)
def event_analytics_detail(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return get_event_analytics_detail(db, event_id, current_user)