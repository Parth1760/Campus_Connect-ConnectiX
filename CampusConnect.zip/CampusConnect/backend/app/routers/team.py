from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.schemas.team import TeamResponse
from app.services.team_service import get_teams_for_event
from app.dependencies import require_roles
from app.models.user import User

router = APIRouter(prefix="/events/{event_id}/teams", tags=["Teams"])


@router.get("/", response_model=List[TeamResponse])
def list_teams_endpoint(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return get_teams_for_event(db, event_id, current_user)