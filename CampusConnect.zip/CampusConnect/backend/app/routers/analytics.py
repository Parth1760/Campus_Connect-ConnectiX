from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.analytics import (EventAnalytics, OverviewAnalytics, AdminAnalyticsPortal, 
                                   FacultyAnalyticsSummary, FacultyDetailAnalytics,
                                   VolunteerAnalyticsSummary, VolunteerDetailAnalytics,
                                   JudgeAnalyticsSummary, JudgeDetailAnalytics)
from app.services.analytics_service import (get_event_analytics, get_overview_analytics, get_admin_analytics_portal,
                                            get_faculty_analytics_list, get_faculty_analytics_detail,
                                            get_volunteer_analytics_list, get_volunteer_analytics_detail,
                                            get_judge_analytics_list, get_judge_analytics_detail)
from app.dependencies import require_roles
from app.models.user import User
from typing import List


router = APIRouter(prefix="/admin/analytics", tags=["Analytics"])


@router.get("/overview", response_model=OverviewAnalytics)
def overview(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_overview_analytics(db)


@router.get("/event/{event_id}", response_model=EventAnalytics)
def event_analytics(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_event_analytics(db, event_id)


@router.get("/portal", response_model=AdminAnalyticsPortal)
def analytics_portal(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_admin_analytics_portal(db)


@router.get("/faculty", response_model=List[FacultyAnalyticsSummary])
def faculty_analytics_list(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_faculty_analytics_list(db)


@router.get("/faculty/{faculty_id}", response_model=FacultyDetailAnalytics)
def faculty_analytics_detail(
    faculty_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_faculty_analytics_detail(db, faculty_id)


@router.get("/volunteers", response_model=List[VolunteerAnalyticsSummary])
def volunteer_analytics_list(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_volunteer_analytics_list(db)


@router.get("/volunteers/{volunteer_id}", response_model=VolunteerDetailAnalytics)
def volunteer_analytics_detail(
    volunteer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_volunteer_analytics_detail(db, volunteer_id)


@router.get("/judges", response_model=List[JudgeAnalyticsSummary])
def judge_analytics_list(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_judge_analytics_list(db)


@router.get("/judges/{judge_id}", response_model=JudgeDetailAnalytics)
def judge_analytics_detail(
    judge_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_judge_analytics_detail(db, judge_id)