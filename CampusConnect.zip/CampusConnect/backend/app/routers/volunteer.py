from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.volunteer import VolunteerDashboardResponse, CheckInHistoryItem, VolunteerAssignRequest, AssignedVolunteer
from app.schemas.user import UserResponse
from app.services.volunteer_service import (
    get_volunteer_dashboard, get_checkin_history,
    assign_volunteer, unassign_volunteer, get_assigned_volunteers
)
from app.dependencies import require_roles
from app.models.user import User

router = APIRouter(prefix="/volunteer", tags=["Volunteer"])


@router.get("/dashboard", response_model=VolunteerDashboardResponse)
def volunteer_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("volunteer", "faculty", "admin"))
):
    return get_volunteer_dashboard(db, current_user.id)


@router.get("/checkin-history", response_model=List[CheckInHistoryItem])
def checkin_history(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("volunteer", "faculty", "admin"))
):
    return get_checkin_history(db)


@router.get("/list", response_model=List[UserResponse])
def list_volunteers(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return db.query(User).filter(User.role == "volunteer", User.is_active == True).all()


@router.post("/events/{event_id}/assign")
def assign_volunteer_endpoint(
    event_id: int,
    data: VolunteerAssignRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    assign_volunteer(db, event_id, data.volunteer_id)
    return {"message": "Volunteer assigned successfully"}


@router.delete("/events/{event_id}/assign/{volunteer_id}")
def unassign_volunteer_endpoint(
    event_id: int,
    volunteer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return unassign_volunteer(db, event_id, volunteer_id)


@router.get("/events/{event_id}/assigned", response_model=List[AssignedVolunteer])
def assigned_volunteers_endpoint(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return get_assigned_volunteers(db, event_id)