from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.schemas.registration import RegistrationResponse, CheckInRequest, CheckInResponse, MyRegistrationSummary, RegisteredStudent, TeamRegisterRequest, TeamRegistrationResponse, QRRefreshResponse
from app.services.registration_service import register_for_event, get_my_registration, check_in_by_qr, get_my_registrations, get_event_registrations, register_team, get_my_team, refresh_qr_code, approve_registration, reject_registration
from app.dependencies import get_current_user, require_roles
from app.models.user import User






router = APIRouter(tags=["Registrations"])


@router.post("/events/{event_id}/register", response_model=RegistrationResponse)
def register(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return register_for_event(db, event_id, current_user.id)


@router.get("/events/{event_id}/my-registration", response_model=RegistrationResponse)
def my_registration(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return get_my_registration(db, event_id, current_user.id)


@router.post("/attendance/check-in", response_model=CheckInResponse)
def check_in(
    data: CheckInRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("volunteer", "faculty", "admin"))
):
    return check_in_by_qr(db, data.qr_code, current_user.id)

@router.get("/my-registrations", response_model=List[MyRegistrationSummary])
def my_registrations(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return get_my_registrations(db, current_user.id)


@router.get("/events/{event_id}/registrations", response_model=List[RegisteredStudent])
def event_registrations(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return get_event_registrations(db, event_id)


@router.post("/events/{event_id}/register-team", response_model=TeamRegistrationResponse)
def register_as_team(
    event_id: int,
    data: TeamRegisterRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return register_team(db, event_id, current_user.id, data.team_name, data.member_emails, data.project_idea)


@router.get("/events/{event_id}/my-team")
def my_team(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = get_my_team(db, event_id, current_user.id)
    if not result:
        raise HTTPException(status_code=404, detail="Not part of a team for this event")
    return result


@router.post("/registrations/{registration_id}/refresh-code", response_model=QRRefreshResponse)
def refresh_code(
    registration_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return refresh_qr_code(db, registration_id, current_user.id)


@router.patch("/events/{event_id}/registrations/{registration_id}/approve", response_model=RegistrationResponse)
def approve_registration_endpoint(
    event_id: int,
    registration_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return approve_registration(db, event_id, registration_id, current_user)


@router.patch("/events/{event_id}/registrations/{registration_id}/reject", response_model=RegistrationResponse)
def reject_registration_endpoint(
    event_id: int,
    registration_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("faculty", "admin"))
):
    return reject_registration(db, event_id, registration_id, current_user)