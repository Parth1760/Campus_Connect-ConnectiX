from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import require_roles
from app.models.user import User
from typing import List
from app.schemas.admin import AdminDashboardResponse, CreateStaffRequest, CreateStaffResponse
from app.schemas.broadcast import BroadcastCreate, BroadcastResponse
from app.services.admin_service import get_admin_dashboard, create_staff_account
from app.services.notification_service import create_broadcast, get_broadcasts
from app.schemas.system_settings import SystemSettingsResponse, SystemSettingsUpdate
from app.services.system_settings_service import get_settings, update_settings

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.get("/dashboard", response_model=AdminDashboardResponse)
def admin_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_admin_dashboard(db)


@router.post("/notifications/broadcast", response_model=BroadcastResponse)
def send_broadcast(
    data: BroadcastCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return create_broadcast(db, data)


@router.get("/notifications/broadcasts", response_model=List[BroadcastResponse])
def list_broadcasts(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_broadcasts(db)


@router.post("/users/create-staff", response_model=CreateStaffResponse)
def create_staff(
    data: CreateStaffRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return create_staff_account(db, data)


@router.get("/settings", response_model=SystemSettingsResponse)
def get_system_settings(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_settings(db)


@router.put("/settings", response_model=SystemSettingsResponse)
def update_system_settings(
    data: SystemSettingsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return update_settings(db, data)