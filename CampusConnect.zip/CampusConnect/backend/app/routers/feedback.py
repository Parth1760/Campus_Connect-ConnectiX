from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.feedback import FeedbackCreate, FeedbackResponse
from app.services.feedback_service import submit_feedback, get_my_feedback
from app.dependencies import get_current_user
from app.models.user import User

router = APIRouter(tags=["Feedback"])


@router.post("/events/{event_id}/feedback", response_model=FeedbackResponse)
def give_feedback(
    event_id: int,
    data: FeedbackCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return submit_feedback(db, event_id, current_user.id, data)


@router.get("/events/{event_id}/my-feedback", response_model=FeedbackResponse)
def my_feedback(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = get_my_feedback(db, event_id, current_user.id)
    if not result:
        raise HTTPException(status_code=404, detail="No feedback submitted yet")
    return result