from fastapi import APIRouter, Depends, HTTPException, Form
from sqlalchemy.orm import Session
from typing import List
from fastapi.responses import HTMLResponse

from app.schemas.password_reset import ForgotPasswordRequest
from app.services.password_reset_service import request_password_reset, reset_password
from app.database import get_db
from app.schemas.user import UserCreate, UserLogin, UserResponse, TokenResponse, UserUpdate, EmailVerifyRequest, ResendOtpRequest, PasswordResetOtpRequest, PasswordResetOtpConfirm, UserDetailResponse, RoleUpdateRequest
from app.services.auth_service import signup_user, login_user, get_all_users, update_user_profile, verify_email_otp, resend_otp, request_password_reset_otp, confirm_password_reset_otp, get_user_details, update_user_role
from app.dependencies import get_current_user, require_roles
from app.models.user import User





router = APIRouter(
    prefix="/auth",
    tags=["Authentication"]
)


@router.post("/signup", response_model=UserResponse)
def signup(
    user: UserCreate, 
    db: Session = Depends(get_db)
):
    return signup_user(db, user)


@router.post("/login", response_model=TokenResponse)
def login(
    user_data: UserLogin,
    db: Session = Depends(get_db)
):
    return login_user(db, user_data)


@router.get("/me", response_model=UserResponse)
def get_me(
    current_user: User = Depends(get_current_user)
):
    return current_user

@router.get("/users", response_model=List[UserResponse])
def list_users(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_all_users(db)


@router.patch("/users/{user_id}/toggle-active")
def toggle_user_active(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    target_user.is_active = not target_user.is_active
    db.commit()
    db.refresh(target_user)
    return {"id": target_user.id, "is_active": target_user.is_active}


@router.post("/forgot-password")
def forgot_password(
    data: ForgotPasswordRequest,
    db: Session = Depends(get_db)
):
    return request_password_reset(db, data.email)


@router.get("/reset-password-page", response_class=HTMLResponse)
def reset_password_page(token: str):
    html_content = f"""
    <html>
    <head>
        <title>Reset Password - CampusConnect</title>
        <style>
            body {{ font-family: Arial, sans-serif; background: #F7F9FF; display: flex; justify-content: center; padding-top: 60px; }}
            .card {{ background: white; padding: 32px; border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); width: 320px; }}
            h2 {{ color: #4E6CFE; }}
            input {{ width: 100%; padding: 12px; margin: 10px 0; border-radius: 10px; border: 1px solid #ddd; box-sizing: border-box; }}
            button {{ width: 100%; padding: 12px; background: #4E6CFE; color: white; border: none; border-radius: 10px; font-weight: bold; cursor: pointer; }}
        </style>
    </head>
    <body>
        <div class="card">
            <h2>Reset Password</h2>
                        <form method="POST" action="/auth/reset-password" onsubmit="return checkMatch()">
                <input type="hidden" name="token" value="{token}">
                <input type="password" id="pwd1" name="new_password" placeholder="New Password" required minlength="6">
                <input type="password" id="pwd2" name="confirm_password" placeholder="Confirm Password" required minlength="6">
                <p id="errorMsg" style="color:red;font-size:13px;display:none;">Passwords do not match</p>
                <button type="submit">Reset Password</button>
            </form>
            <script>
                function checkMatch() {{
                    var p1 = document.getElementById('pwd1').value;
                    var p2 = document.getElementById('pwd2').value;
                    if (p1 !== p2) {{
                        document.getElementById('errorMsg').style.display = 'block';
                        return false;
                    }}
                    return true;
                }}
            </script>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)


@router.post("/reset-password", response_class=HTMLResponse)
def reset_password_submit(
    token: str = Form(...),
    new_password: str = Form(...),
    confirm_password: str = Form(...),
    db: Session = Depends(get_db)
):
    if new_password != confirm_password:
        return HTMLResponse(content="<h2 style='font-family:Arial;text-align:center;margin-top:100px;color:red;'>Passwords do not match. Please go back and try again.</h2>")

    try:
        reset_password(db, token, new_password)
        return HTMLResponse(content="<h2 style='font-family:Arial;text-align:center;margin-top:100px;color:#00875A;'>Password reset successful! You can now login with your new password.</h2>")
    except HTTPException as e:
        return HTMLResponse(content=f"<h2 style='font-family:Arial;text-align:center;margin-top:100px;color:red;'>{e.detail}</h2>")


@router.put("/me", response_model=UserResponse)
def update_profile(
    update_data: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return update_user_profile(db, current_user, update_data)

@router.post("/verify-email")
def verify_email(
    data: EmailVerifyRequest,
    db: Session = Depends(get_db)
):
    return verify_email_otp(db, data.email, data.otp_code)


@router.post("/resend-otp")
def resend_verification_otp(
    data: ResendOtpRequest,
    db: Session = Depends(get_db)
):
    return resend_otp(db, data.email)


@router.post("/request-password-reset-otp")
def request_reset_otp(
    data: PasswordResetOtpRequest,
    db: Session = Depends(get_db)
):
    return request_password_reset_otp(db, data.email)


@router.post("/confirm-password-reset-otp")
def confirm_reset_otp(
    data: PasswordResetOtpConfirm,
    db: Session = Depends(get_db)
):
    return confirm_password_reset_otp(db, data.email, data.otp_code, data.new_password)


@router.get("/users/{user_id}/details", response_model=UserDetailResponse)
def user_details(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return get_user_details(db, user_id)


@router.patch("/users/{user_id}/role", response_model=UserResponse)
def change_user_role(
    user_id: int,
    data: RoleUpdateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin"))
):
    return update_user_role(db, user_id, data.role)