from pydantic import BaseModel
from typing import List
from datetime import datetime


class ManagedEventSummary(BaseModel):
    id: int
    title: str
    event_date: datetime
    registration_count: int
    status: str


class FacultyDashboardResponse(BaseModel):
    total_events: int
    active_events: int
    total_registrations: int
    attendance_rate: float
    managed_events: List[ManagedEventSummary]


class DailyTrendPoint(BaseModel):
    date: str
    count: int


class EventAnalyticsDetail(BaseModel):
    event_id: int
    event_title: str
    total_registered: int
    total_attended: int
    attendance_rate: float
    avg_rating: float
    certs_issued: int
    daily_trend: List[DailyTrendPoint]