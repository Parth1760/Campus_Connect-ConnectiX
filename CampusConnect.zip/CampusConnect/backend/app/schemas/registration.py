from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List


class RegistrationResponse(BaseModel):
    id: int
    event_id: int
    user_id: int
    team_id: Optional[int] = None
    qr_code: str
    status: str = "pending"
    is_attended: bool
    registered_at: datetime

    class Config:
        from_attributes = True


class CheckInRequest(BaseModel):
    qr_code: str


class CheckInResponse(BaseModel):
    registration_id: int
    student_name: str
    student_email: str
    student_college: Optional[str] = None
    event_title: str
    already_checked_in: bool
    checked_in_at: Optional[datetime] = None
    message: str


class MyRegistrationSummary(BaseModel):
    registration_id: int
    event_id: int
    event_title: str
    event_venue: str
    event_date: Optional[datetime] = None
    qr_code: str
    status: str = "pending"
    is_attended: bool
    score: Optional[float] = None
    team_id: Optional[int] = None
    team_name: Optional[str] = None


class RegisteredStudent(BaseModel):
    registration_id: int
    student_id: int
    student_name: str
    student_email: str
    student_phone: str
    enrollment_number: Optional[str] = None
    department: Optional[str] = None
    year: Optional[str] = None
    status: str = "pending"
    is_attended: bool
    registered_at: datetime
    team_id: Optional[int] = None
    team_name: Optional[str] = None


class TeamRegisterRequest(BaseModel):
    team_name: str
    project_idea: Optional[str] = None
    member_emails: List[str] = []


class TeamMemberInfo(BaseModel):
    student_name: str
    student_email: str
    qr_code: str


class TeamRegistrationResponse(BaseModel):
    team_id: int
    team_name: str
    project_idea: Optional[str] = None
    event_id: int
    members: List[TeamMemberInfo]


class QRRefreshResponse(BaseModel):
    registration_id: int
    qr_code: str