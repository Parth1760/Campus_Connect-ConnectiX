from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class AssignedEventSummary(BaseModel):
    id: int
    title: str
    venue: Optional[str] = None
    event_date: datetime
    checked_in: int
    pending: int


class UpcomingScheduleItem(BaseModel):
    id: int
    title: str
    event_date: datetime


class VolunteerDashboardResponse(BaseModel):
    today_assignment: Optional[AssignedEventSummary] = None
    upcoming_schedules: List[UpcomingScheduleItem]

class CheckInHistoryItem(BaseModel):
    registration_id: int
    student_name: str
    student_college: Optional[str] = None
    event_title: str
    checked_in_at: Optional[datetime] = None


class VolunteerAssignRequest(BaseModel):
    volunteer_id: int


class AssignedVolunteer(BaseModel):
    id: int
    volunteer_id: int
    volunteer_name: str
    volunteer_email: str