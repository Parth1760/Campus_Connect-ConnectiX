from pydantic import BaseModel
from typing import Optional


class SystemSettingsResponse(BaseModel):
    app_name: str
    default_language: str
    timezone: str
    max_team_size: int
    registration_buffer_hours: int
    session_timeout_minutes: int
    two_factor_enabled: bool

    class Config:
        from_attributes = True


class SystemSettingsUpdate(BaseModel):
    app_name: Optional[str] = None
    default_language: Optional[str] = None
    timezone: Optional[str] = None
    max_team_size: Optional[int] = None
    registration_buffer_hours: Optional[int] = None
    session_timeout_minutes: Optional[int] = None
    two_factor_enabled: Optional[bool] = None