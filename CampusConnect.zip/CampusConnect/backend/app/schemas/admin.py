from pydantic import BaseModel
from typing import List
from datetime import datetime


class RecentActivityItem(BaseModel):
    type: str
    message: str
    timestamp: datetime


class AdminDashboardResponse(BaseModel):
    total_users: int
    total_events: int
    active_events: int
    total_registrations: int
    attendance_rate: float
    recent_activity: List[RecentActivityItem]


class CreateStaffRequest(BaseModel):
    full_name: str
    email: str
    phone: str
    role: str
    college: str | None = None
    department: str | None = None


class CreateStaffResponse(BaseModel):
    id: int
    full_name: str
    email: str
    role: str
    message: str