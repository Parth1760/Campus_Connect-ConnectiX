from pydantic import BaseModel
from datetime import datetime


class BroadcastCreate(BaseModel):
    target_role: str
    title: str
    message: str


class BroadcastResponse(BaseModel):
    id: int
    title: str
    message: str
    target_role: str
    recipient_count: int
    read_count: int
    read_rate: float
    created_at: datetime

    class Config:
        from_attributes = True