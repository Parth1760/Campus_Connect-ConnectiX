from pydantic import BaseModel, EmailStr
from typing import Optional

class UserCreate(BaseModel):
    full_name: str
    email: EmailStr
    phone: str
    password: str
    role: str
    enrollment_number: Optional[str] = None    
    department: Optional[str] = None          
    year: Optional[str] = None
    college: Optional[str] = None
    confirm_password: Optional[str] = None                


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: int
    full_name: str
    email: str
    phone: str
    role: str
    enrollment_number: Optional[str] = None    
    department: Optional[str] = None          
    year: Optional[str] = None
    college: Optional[str] = None  

    class Config:
        from_attributes = True

class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    department: Optional[str] = None
    enrollment_number: Optional[str] = None
    year: Optional[str] = None


class EmailVerifyRequest(BaseModel):
    email: EmailStr
    otp_code: str


class ResendOtpRequest(BaseModel):
    email: EmailStr


class PasswordResetOtpRequest(BaseModel):
    email: EmailStr


class PasswordResetOtpConfirm(BaseModel):
    email: EmailStr
    otp_code: str
    new_password: str


class UserDetailResponse(BaseModel):
    id: int
    full_name: str
    email: str
    phone: str
    role: str
    college: Optional[str] = None
    department: Optional[str] = None
    is_active: bool
    created_at: Optional[str] = None
    registered_count: int
    attended_count: int
    certificates_count: int

    class Config:
        from_attributes = True


class RoleUpdateRequest(BaseModel):
    role: str