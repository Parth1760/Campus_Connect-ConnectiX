from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class CertificateResponse(BaseModel):
    registration_id: int
    certificate_id: str
    student_name: str
    event_title: str
    event_date: datetime
    issued_at: Optional[datetime] = None
    rank: Optional[int] = None
    team_name: Optional[str] = None


class CertificateVerifyResponse(BaseModel):
    valid: bool
    student_name: Optional[str] = None
    event_title: Optional[str] = None
    event_date: Optional[datetime] = None
    rank: Optional[int] = None