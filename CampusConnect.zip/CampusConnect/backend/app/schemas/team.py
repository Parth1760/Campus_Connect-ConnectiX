from pydantic import BaseModel
from datetime import datetime


class TeamResponse(BaseModel):
    id: int
    event_id: int
    team_name: str
    created_by: int
    member_count: int
    created_at: datetime

    class Config:
        from_attributes = True