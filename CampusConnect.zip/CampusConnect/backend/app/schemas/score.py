from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime


class ScoreCreate(BaseModel):
    registration_id: int
    score: float
    remarks: Optional[str] = None


class ScoreResponse(BaseModel):
    id: int
    event_id: int
    registration_id: Optional[int] = None
    judge_id: int
    score: float
    remarks: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ParticipantForJudging(BaseModel):
    registration_id: int
    student_id: int
    student_name: str
    student_email: str
    is_attended: bool
    my_score: Optional[float] = None
    my_remarks: Optional[str] = None

class LeaderboardEntry(BaseModel):
    rank: int
    student_name: str
    average_score: float
    total_judges: int


class TeamScoreCreate(BaseModel):
    team_id: int
    innovation: int = Field(..., ge=0, le=25)
    technical_implementation: int = Field(..., ge=0, le=25)
    presentation: int = Field(..., ge=0, le=25)
    problem_solving: int = Field(..., ge=0, le=25)
    remarks: Optional[str] = None


class TeamScoreResponse(BaseModel):
    id: int
    event_id: int
    team_id: Optional[int] = None
    judge_id: int
    innovation: Optional[int] = None
    technical_implementation: Optional[int] = None
    presentation: Optional[int] = None
    problem_solving: Optional[int] = None
    score: float
    remarks: Optional[str] = None

    class Config:
        from_attributes = True


class TeamForJudging(BaseModel):
    team_id: int
    team_name: str
    project_idea: Optional[str] = None
    member_count: int
    status: str
    my_score: Optional[float] = None
    my_innovation: Optional[int] = None
    my_technical_implementation: Optional[int] = None
    my_presentation: Optional[int] = None
    my_problem_solving: Optional[int] = None
    my_remarks: Optional[str] = None


class TeamLeaderboardEntry(BaseModel):
    rank: int
    team_name: str
    average_score: float
    total_judges: int


class JudgeAssignmentSummary(BaseModel):
    event_id: int
    event_title: str
    venue: Optional[str] = None
    total_teams: int
    evaluated_count: int
    percent_evaluated: float
    remaining: int


class JudgeUpcomingItem(BaseModel):
    event_id: int
    title: str
    event_date: datetime


class JudgeDashboardResponse(BaseModel):
    teams_evaluated: int
    total_teams: int
    avg_score_given: float
    current_assignment: Optional[JudgeAssignmentSummary] = None
    upcoming: List[JudgeUpcomingItem]