from pydantic import BaseModel
from typing import List


class DepartmentStat(BaseModel):
    department: str
    registered_count: int
    attended_count: int


class EventAnalytics(BaseModel):
    event_id: int
    event_title: str
    total_registered: int
    total_attended: int
    attendance_rate: float
    department_breakdown: List[DepartmentStat]


class EventSummaryStat(BaseModel):
    event_id: int
    event_title: str
    registered_count: int
    attended_count: int


class OverviewAnalytics(BaseModel):
    total_events: int
    total_registrations: int
    total_attendances: int
    events_summary: List[EventSummaryStat]


class WeeklyTrendPoint(BaseModel):
    week_label: str
    count: int


class CategoryStat(BaseModel):
    category: str
    count: int


class AdminAnalyticsPortal(BaseModel):
    new_users_30d: int
    avg_attendance: float
    events_held_30d: int
    certs_issued: int
    registrations_trend: List[WeeklyTrendPoint]
    popular_categories: List[CategoryStat]


from datetime import datetime
from typing import Optional


class FacultyAnalyticsSummary(BaseModel):
    id: int
    full_name: str
    email: str
    department: Optional[str] = None
    total_events: int
    total_registrations: int
    total_attended: int
    attendance_rate: float
    avg_rating: float


class FacultyEventDetail(BaseModel):
    event_id: int
    title: str
    event_date: datetime
    registration_count: int
    attended_count: int


class FacultyDetailAnalytics(BaseModel):
    id: int
    full_name: str
    email: str
    department: Optional[str] = None
    total_events: int
    total_registrations: int
    total_attended: int
    attendance_rate: float
    avg_rating: float
    events: List[FacultyEventDetail]


class VolunteerAnalyticsSummary(BaseModel):
    id: int
    full_name: str
    email: str
    total_checkins: int
    events_worked: int


class VolunteerCheckinDetail(BaseModel):
    student_name: str
    event_title: str
    checked_in_at: Optional[datetime] = None


class VolunteerDetailAnalytics(BaseModel):
    id: int
    full_name: str
    email: str
    total_checkins: int
    events_worked: int
    assigned_events: List[str]
    recent_checkins: List[VolunteerCheckinDetail]


class JudgeAnalyticsSummary(BaseModel):
    id: int
    full_name: str
    email: str
    total_evaluations: int
    avg_score_given: float
    events_judged: int


class JudgeEvaluationDetail(BaseModel):
    team_name: str
    event_title: str
    score: float


class JudgeDetailAnalytics(BaseModel):
    id: int
    full_name: str
    email: str
    total_evaluations: int
    avg_score_given: float
    events_judged: int
    evaluations: List[JudgeEvaluationDetail]