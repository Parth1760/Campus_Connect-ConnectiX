from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class EventCreate(BaseModel):
    title: str
    description: Optional[str] = None
    venue: Optional[str] = None
    event_date: datetime
    category: Optional[str] = None
    max_participants: Optional[int] = None
    allow_team_registration: bool = True
    banner_url: Optional[str] = None


class EventResponse(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    venue: Optional[str] = None
    event_date: datetime
    created_by: int
    created_at: Optional[datetime] = None
    registration_count: int = 0
    category: Optional[str] = None
    max_participants: Optional[int] = None
    allow_team_registration: bool = True
    coordinator_name: Optional[str] = None
    banner_url: Optional[str] = None

    class Config:
        from_attributes = True

class EventUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    venue: Optional[str] = None
    event_date: Optional[datetime] = None
    category: Optional[str] = None
    max_participants: Optional[int] = None
    allow_team_registration: Optional[bool] = None
    banner_url: Optional[str] = None