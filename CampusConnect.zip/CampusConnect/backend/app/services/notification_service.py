from sqlalchemy.orm import Session

from app.models.notification import Notification
from fastapi import HTTPException
from app.models.broadcast import Broadcast
from app.models.user import User


def create_notification(db: Session, user_id: int, title: str, message: str):
    notification = Notification(user_id=user_id, title=title, message=message)
    db.add(notification)
    db.commit()
    db.refresh(notification)
    return notification


def get_my_notifications(db: Session, user_id: int):
    return db.query(Notification).filter(
        Notification.user_id == user_id
    ).order_by(Notification.created_at.desc()).all()


def get_unread_count(db: Session, user_id: int):
    return db.query(Notification).filter(
        Notification.user_id == user_id,
        Notification.is_read == False
    ).count()


def mark_as_read(db: Session, notification_id: int, user_id: int):
    notification = db.query(Notification).filter(
        Notification.id == notification_id,
        Notification.user_id == user_id
    ).first()
    if notification:
        notification.is_read = True
        db.commit()
    return notification


def mark_all_as_read(db: Session, user_id: int):
    db.query(Notification).filter(
        Notification.user_id == user_id,
        Notification.is_read == False
    ).update({"is_read": True})
    db.commit()


VALID_TARGETS = ["all", "student", "faculty", "volunteer", "judge"]


def create_broadcast(db: Session, data):
    if data.target_role not in VALID_TARGETS:
        raise HTTPException(status_code=400, detail=f"Invalid target. Must be one of: {', '.join(VALID_TARGETS)}")

    if data.target_role == "all":
        recipients = db.query(User).all()
    else:
        recipients = db.query(User).filter(User.role == data.target_role).all()

    new_broadcast = Broadcast(
        title=data.title,
        message=data.message,
        target_role=data.target_role,
        recipient_count=len(recipients),
    )
    db.add(new_broadcast)
    db.commit()
    db.refresh(new_broadcast)

    for user in recipients:
        notification = Notification(
            user_id=user.id,
            broadcast_id=new_broadcast.id,
            title=data.title,
            message=data.message,
        )
        db.add(notification)
    db.commit()

    return {
        "id": new_broadcast.id,
        "title": new_broadcast.title,
        "message": new_broadcast.message,
        "target_role": new_broadcast.target_role,
        "recipient_count": new_broadcast.recipient_count,
        "read_count": 0,
        "read_rate": 0.0,
        "created_at": new_broadcast.created_at,
    }


def get_broadcasts(db: Session):
    broadcasts = db.query(Broadcast).order_by(Broadcast.created_at.desc()).all()

    result = []
    for b in broadcasts:
        read_count = db.query(Notification).filter(
            Notification.broadcast_id == b.id,
            Notification.is_read == True
        ).count()
        read_rate = round((read_count / b.recipient_count * 100), 0) if b.recipient_count > 0 else 0.0

        result.append({
            "id": b.id,
            "title": b.title,
            "message": b.message,
            "target_role": b.target_role,
            "recipient_count": b.recipient_count,
            "read_count": read_count,
            "read_rate": read_rate,
            "created_at": b.created_at,
        })
    return result