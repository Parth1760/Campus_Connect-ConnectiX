from sqlalchemy.orm import Session
from fastapi import HTTPException
from datetime import datetime, timezone

from app.models.event import Event
from app.models.registration import Registration
from app.models.user import User
from app.models.volunteer_assignment import VolunteerAssignment


def _event_date_aware(event):
    d = event.event_date
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def get_volunteer_dashboard(db: Session, volunteer_id: int):
    now = datetime.now(timezone.utc)

    assignments = db.query(VolunteerAssignment).filter(VolunteerAssignment.volunteer_id == volunteer_id).all()
    assigned_event_ids = [a.event_id for a in assignments]

    assigned_events = []
    if assigned_event_ids:
        assigned_events = db.query(Event).filter(Event.id.in_(assigned_event_ids)).order_by(Event.event_date.asc()).all()

    today_event = None
    for event in assigned_events:
        if _event_date_aware(event).date() == now.date():
            today_event = event
            break
    if today_event is None:
        for event in assigned_events:
            if _event_date_aware(event) >= now:
                today_event = event
                break

    today_assignment = None
    if today_event:
        registrations = db.query(Registration).filter(
            Registration.event_id == today_event.id,
            Registration.status == "approved"
        ).all()
        checked_in = len([r for r in registrations if r.is_attended])
        pending = len(registrations) - checked_in

        today_assignment = {
            "id": today_event.id,
            "title": today_event.title,
            "venue": today_event.venue,
            "event_date": today_event.event_date,
            "checked_in": checked_in,
            "pending": pending,
        }

    upcoming = []
    for event in assigned_events:
        if today_event and event.id == today_event.id:
            continue
        if _event_date_aware(event) >= now:
            upcoming.append({"id": event.id, "title": event.title, "event_date": event.event_date})
        if len(upcoming) >= 5:
            break

    return {"today_assignment": today_assignment, "upcoming_schedules": upcoming}


def get_checkin_history(db: Session):
    registrations = db.query(Registration).filter(
        Registration.is_attended == True
    ).order_by(Registration.checked_in_at.desc()).limit(100).all()

    result = []
    for reg in registrations:
        student = db.query(User).filter(User.id == reg.user_id).first()
        event = db.query(Event).filter(Event.id == reg.event_id).first()
        result.append({
            "registration_id": reg.id,
            "student_name": student.full_name if student else "Unknown",
            "student_college": student.college if student else None,
            "event_title": event.title if event else "Unknown",
            "checked_in_at": reg.checked_in_at,
        })
    return result


def assign_volunteer(db: Session, event_id: int, volunteer_id: int):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    volunteer = db.query(User).filter(User.id == volunteer_id, User.role == "volunteer").first()
    if not volunteer:
        raise HTTPException(status_code=404, detail="Volunteer not found")

    existing = db.query(VolunteerAssignment).filter(
        VolunteerAssignment.event_id == event_id,
        VolunteerAssignment.volunteer_id == volunteer_id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Volunteer is already assigned to this event")

    assignment = VolunteerAssignment(event_id=event_id, volunteer_id=volunteer_id)
    db.add(assignment)
    db.commit()
    db.refresh(assignment)
    return assignment


def unassign_volunteer(db: Session, event_id: int, volunteer_id: int):
    assignment = db.query(VolunteerAssignment).filter(
        VolunteerAssignment.event_id == event_id,
        VolunteerAssignment.volunteer_id == volunteer_id
    ).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")
    db.delete(assignment)
    db.commit()
    return {"message": "Volunteer unassigned"}


def get_assigned_volunteers(db: Session, event_id: int):
    rows = db.query(VolunteerAssignment).filter(VolunteerAssignment.event_id == event_id).all()
    result = []
    for r in rows:
        v = db.query(User).filter(User.id == r.volunteer_id).first()
        result.append({
            "id": r.id,
            "volunteer_id": r.volunteer_id,
            "volunteer_name": v.full_name if v else "Unknown",
            "volunteer_email": v.email if v else "",
        })
    return result