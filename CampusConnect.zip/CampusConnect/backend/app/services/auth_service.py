from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.user import User
from app.repositories.user_repository import get_user_by_email, create_user
from app.utils.security import hash_password, verify_password, create_access_token
from datetime import datetime, timedelta, timezone
from app.models.email_verification import EmailVerification
from app.services.email_service import send_otp_email
from app.models.registration import Registration
from app.services.system_settings_service import get_settings


def signup_user(db: Session, user_data):
    if user_data.confirm_password is not None and user_data.password != user_data.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    existing_user = get_user_by_email(db, user_data.email)
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    existing_phone = db.query(User).filter(User.phone == user_data.phone).first()
    if existing_phone:
        raise HTTPException(status_code=400, detail="Phone number already registered")

    new_user = User(
        full_name=user_data.full_name,
        email=user_data.email,
        phone=user_data.phone,
        password=hash_password(user_data.password),
        role="student",
        enrollment_number=user_data.enrollment_number,
        department=user_data.department,
        year=user_data.year,
        college=user_data.college,
        is_active=True,
        is_verified=False
    )

    created_user = create_user(db, new_user)

    otp_entry = EmailVerification(email=user_data.email)
    db.add(otp_entry)
    db.commit()
    db.refresh(otp_entry)
    send_otp_email(user_data.email, otp_entry.otp_code)

    return created_user


def login_user(db: Session, user_data):

    # Find user
    user = get_user_by_email(db, user_data.email)

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    # Verify password
    if not verify_password(user_data.password, user.password):
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    if not user.is_verified:
        raise HTTPException(status_code=403, detail="Please verify your email before logging in")

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Your account has been deactivated. Please contact the admin.")

        # Create JWT token
    settings = get_settings(db)
    access_token = create_access_token(
        data={
            "sub": str(user.id),
            "email": user.email,
            "role": user.role
        },
        expires_minutes=settings.session_timeout_minutes
    )

    # Return token + user information
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "phone": user.phone,
            "role": user.role
        }
    }

def get_all_users(db: Session):
    return db.query(User).all()


def update_user_profile(db: Session, current_user, update_data):
    user = db.query(User).filter(User.id == current_user.id).first()

    if update_data.full_name is not None:
        user.full_name = update_data.full_name

    if update_data.phone is not None:
        existing = db.query(User).filter(
            User.phone == update_data.phone,
            User.id != user.id
        ).first()
        if existing:
            raise HTTPException(status_code=400, detail="Phone number already in use")
        user.phone = update_data.phone

    if update_data.department is not None:
        user.department = update_data.department
    if update_data.enrollment_number is not None:
        user.enrollment_number = update_data.enrollment_number
    if update_data.year is not None:
        user.year = update_data.year

    db.commit()
    db.refresh(user)
    return user

def verify_email_otp(db: Session, email: str, otp_code: str):
    otp_entry = db.query(EmailVerification).filter(
        EmailVerification.email == email,
        EmailVerification.otp_code == otp_code,
        EmailVerification.is_used == False
    ).order_by(EmailVerification.created_at.desc()).first()

    if not otp_entry:
        raise HTTPException(status_code=400, detail="Invalid verification code")

    expiry_time = otp_entry.created_at + timedelta(minutes=10)
    if datetime.now(timezone.utc) > expiry_time.replace(tzinfo=timezone.utc):
        raise HTTPException(status_code=400, detail="Verification code expired")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.is_verified = True
    otp_entry.is_used = True
    db.commit()

    return {"message": "Email verified successfully"}


def resend_otp(db: Session, email: str):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    otp_entry = EmailVerification(email=email)
    db.add(otp_entry)
    db.commit()
    db.refresh(otp_entry)
    send_otp_email(email, otp_entry.otp_code)

    return {"message": "OTP resent successfully"}


def request_password_reset_otp(db: Session, email: str):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        return {"message": "If this email is registered, a code has been sent."}

    otp_entry = EmailVerification(email=email)
    db.add(otp_entry)
    db.commit()
    db.refresh(otp_entry)
    send_otp_email(email, otp_entry.otp_code)

    return {"message": "If this email is registered, a code has been sent."}


def confirm_password_reset_otp(db: Session, email: str, otp_code: str, new_password: str):
    otp_entry = db.query(EmailVerification).filter(
        EmailVerification.email == email,
        EmailVerification.otp_code == otp_code,
        EmailVerification.is_used == False
    ).order_by(EmailVerification.created_at.desc()).first()

    if not otp_entry:
        raise HTTPException(status_code=400, detail="Invalid verification code")

    expiry_time = otp_entry.created_at + timedelta(minutes=10)
    if datetime.now(timezone.utc) > expiry_time.replace(tzinfo=timezone.utc):
        raise HTTPException(status_code=400, detail="Verification code expired")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.password = hash_password(new_password)
    otp_entry.is_used = True
    db.commit()

    return {"message": "Password reset successful"}


VALID_ROLES = ["student", "faculty", "volunteer", "judge", "admin"]


def get_user_details(db: Session, user_id: int):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    registrations = db.query(Registration).filter(Registration.user_id == user_id).all()
    registered_count = len(registrations)
    attended_count = len([r for r in registrations if r.is_attended])
    certificates_count = len([r for r in registrations if r.certificate_id])

    return {
        "id": user.id,
        "full_name": user.full_name,
        "email": user.email,
        "phone": user.phone,
        "role": user.role,
        "college": user.college,
        "department": user.department,
        "is_active": user.is_active,
        "created_at": user.created_at.isoformat() if user.created_at else None,
        "registered_count": registered_count,
        "attended_count": attended_count,
        "certificates_count": certificates_count,
    }


def update_user_role(db: Session, user_id: int, new_role: str):
    if new_role not in VALID_ROLES:
        raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {', '.join(VALID_ROLES)}")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.role = new_role
    db.commit()
    db.refresh(user)
    return user