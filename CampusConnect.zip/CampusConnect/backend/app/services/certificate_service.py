import uuid
from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.registration import Registration
from app.models.event import Event
from app.models.user import User
from app.models.team import Team
from app.models.score import Score


def _calculate_rank(db: Session, registration: Registration):
    """Returns (rank, team_name). Rank is only returned for top 3, else None."""
    event_id = registration.event_id

    # --- Team-based ranking ---
    if registration.team_id:
        team = db.query(Team).filter(Team.id == registration.team_id).first()
        team_name = team.team_name if team else None

        teams = db.query(Team).filter(Team.event_id == event_id).all()
        entries = []
        for t in teams:
            scores = db.query(Score).filter(Score.team_id == t.id).all()
            if not scores:
                continue
            avg = sum(s.score for s in scores) / len(scores)
            entries.append((t.id, avg))

        entries.sort(key=lambda x: x[1], reverse=True)
        for idx, (tid, _) in enumerate(entries):
            if tid == registration.team_id:
                rank = idx + 1
                return (rank if rank <= 3 else None), team_name
        return None, team_name

    # --- Individual ranking ---
    registrations = db.query(Registration).filter(
        Registration.event_id == event_id,
        Registration.is_attended == True
    ).all()

    entries = []
    for reg in registrations:
        scores = db.query(Score).filter(Score.registration_id == reg.id).all()
        if not scores:
            continue
        avg = sum(s.score for s in scores) / len(scores)
        entries.append((reg.id, avg))

    entries.sort(key=lambda x: x[1], reverse=True)
    for idx, (rid, _) in enumerate(entries):
        if rid == registration.id:
            rank = idx + 1
            return (rank if rank <= 3 else None), None

    return None, None


def get_or_create_certificate(db: Session, event_id: int, user_id: int):
    registration = db.query(Registration).filter(
        Registration.event_id == event_id,
        Registration.user_id == user_id
    ).first()

    if not registration or not registration.is_attended:
        raise HTTPException(status_code=400, detail="Certificate available only after attendance is marked")

    if not registration.certificate_id:
        registration.certificate_id = str(uuid.uuid4())
        db.commit()
        db.refresh(registration)

    event = db.query(Event).filter(Event.id == event_id).first()
    student = db.query(User).filter(User.id == user_id).first()
    rank, team_name = _calculate_rank(db, registration)

    return {
        "registration_id": registration.id,
        "certificate_id": registration.certificate_id,
        "student_name": student.full_name if student else "Unknown",
        "event_title": event.title if event else "Unknown",
        "event_date": event.event_date if event else None,
        "issued_at": registration.checked_in_at,
        "rank": rank,
        "team_name": team_name,
    }


def verify_certificate(db: Session, certificate_id: str):
    registration = db.query(Registration).filter(Registration.certificate_id == certificate_id).first()
    if not registration:
        return {"valid": False}

    event = db.query(Event).filter(Event.id == registration.event_id).first()
    student = db.query(User).filter(User.id == registration.user_id).first()
    rank, _ = _calculate_rank(db, registration)

    return {
        "valid": True,
        "student_name": student.full_name if student else "Unknown",
        "event_title": event.title if event else "Unknown",
        "event_date": event.event_date if event else None,
        "rank": rank,
    }