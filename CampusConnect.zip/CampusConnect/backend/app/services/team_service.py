from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.team import Team
from app.models.registration import Registration
from app.models.event import Event


def _member_count(db: Session, team_id: int) -> int:
    return db.query(Registration).filter(Registration.team_id == team_id).count()


def get_teams_for_event(db: Session, event_id: int, current_user):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    if current_user.role != "admin" and event.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="You can only view teams for your own events")

    teams = db.query(Team).filter(Team.event_id == event_id).all()

    result = []
    for team in teams:
        result.append({
            "id": team.id,
            "event_id": team.event_id,
            "team_name": team.team_name,
            "created_by": team.created_by,
            "member_count": _member_count(db, team.id),
            "created_at": team.created_at,
        })
    return result