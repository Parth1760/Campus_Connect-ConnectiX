import uuid
from sqlalchemy.orm import Session
from fastapi import HTTPException
from datetime import datetime, timezone, timedelta
from app.models.score import Score
from app.models.team import Team

from app.models.registration import Registration
from app.models.event import Event
from app.models.user import User
from app.services.notification_service import create_notification
from app.services.system_settings_service import get_settings


def _registration_deadline_check(db: Session, event: Event):
    settings = get_settings(db)
    now = datetime.now(timezone.utc)
    event_date = event.event_date if event.event_date.tzinfo else event.event_date.replace(tzinfo=timezone.utc)
    cutoff = event_date - timedelta(hours=settings.registration_buffer_hours)
    if now > cutoff:
        raise HTTPException(status_code=400, detail="Registration is closed for this event.")
    return settings


def register_for_event(db: Session, event_id: int, user_id: int):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    existing = db.query(Registration).filter(
        Registration.event_id == event_id,
        Registration.user_id == user_id
    ).first()
    if existing:
        return existing

    _registration_deadline_check(db, event)

    if event.max_participants is not None:
        current_count = db.query(Registration).filter(Registration.event_id == event_id).count()
        if current_count >= event.max_participants:
            raise HTTPException(status_code=400, detail="This event is full. Registration is closed.")

    new_registration = Registration(event_id=event_id, user_id=user_id)
    db.add(new_registration)
    db.commit()
    db.refresh(new_registration)

    create_notification(
        db, user_id,
        "Registration Confirmed",
        f"You've successfully registered for '{event.title}'."
    )

    return new_registration


def get_my_registration(db: Session, event_id: int, user_id: int):
    registration = db.query(Registration).filter(
        Registration.event_id == event_id,
        Registration.user_id == user_id
    ).first()
    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found. Please register first.")
    return registration


def check_in_by_qr(db: Session, qr_code: str, checked_in_by_id: int):
    registration = db.query(Registration).filter(Registration.qr_code == qr_code).first()
    if not registration:
        raise HTTPException(status_code=404, detail="Invalid QR code")

    student = db.query(User).filter(User.id == registration.user_id).first()
    event = db.query(Event).filter(Event.id == registration.event_id).first()

    already = registration.is_attended

    if not already:
        registration.is_attended = True
        registration.checked_in_at = datetime.now(timezone.utc)
        registration.checked_in_by = checked_in_by_id
        db.commit()
        db.refresh(registration)

        create_notification(
            db, registration.user_id,
            "Attendance Marked",
            f"Your attendance for '{event.title}' has been marked. Enjoy the event!"
        )

    return {
        "registration_id": registration.id,
        "student_name": student.full_name if student else "Unknown",
        "student_email": student.email if student else "",
        "student_college": student.college if student else None,
        "event_title": event.title if event else "",
        "already_checked_in": already,
        "checked_in_at": registration.checked_in_at,
        "message": "Already checked in before" if already else "Check-in successful!",
    }


def get_my_registrations(db: Session, user_id: int):
    registrations = db.query(Registration).filter(Registration.user_id == user_id).all()
    result = []
    for reg in registrations:
        event = db.query(Event).filter(Event.id == reg.event_id).first()

        scores = db.query(Score).filter(Score.registration_id == reg.id).all()
        avg_score = round(sum(s.score for s in scores) / len(scores), 1) if scores else None

        team = db.query(Team).filter(Team.id == reg.team_id).first() if reg.team_id else None

        result.append({
            "registration_id": reg.id,
            "event_id": reg.event_id,
            "event_title": event.title if event else "Unknown",
            "event_venue": event.venue if event else "",
            "event_date": event.event_date if event else None,
            "qr_code": reg.qr_code,
            "status": reg.status,
            "is_attended": reg.is_attended,
            "score": avg_score,
            "team_id": reg.team_id,
            "team_name": team.team_name if team else None,
        })
    return result


def get_event_registrations(db: Session, event_id: int):
    registrations = db.query(Registration).filter(Registration.event_id == event_id).all()
    result = []
    for reg in registrations:
        student = db.query(User).filter(User.id == reg.user_id).first()
        team = db.query(Team).filter(Team.id == reg.team_id).first() if reg.team_id else None
        result.append({
            "registration_id": reg.id,
            "student_id": reg.user_id,
            "student_name": student.full_name if student else "Unknown",
            "student_email": student.email if student else "",
            "student_phone": student.phone if student else "",
            "enrollment_number": student.enrollment_number if student else None,
            "department": student.department if student else None,
            "year": student.year if student else None,
            "status": reg.status,
            "is_attended": reg.is_attended,
            "registered_at": reg.registered_at,
            "team_id": reg.team_id,
            "team_name": team.team_name if team else None,
        })
    return result


def _get_registration_for_management(db: Session, event_id: int, registration_id: int, current_user):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    if current_user.role != "admin" and event.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="You can only manage registrations for your own events")

    registration = db.query(Registration).filter(
        Registration.id == registration_id,
        Registration.event_id == event_id
    ).first()
    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")

    return registration, event


def approve_registration(db: Session, event_id: int, registration_id: int, current_user):
    registration, event = _get_registration_for_management(db, event_id, registration_id, current_user)

    registration.status = "approved"
    db.commit()
    db.refresh(registration)

    create_notification(
        db, registration.user_id,
        "Registration Approved",
        f"Your registration for '{event.title}' has been approved."
    )

    return registration


def reject_registration(db: Session, event_id: int, registration_id: int, current_user):
    registration, event = _get_registration_for_management(db, event_id, registration_id, current_user)

    registration.status = "rejected"
    db.commit()
    db.refresh(registration)

    create_notification(
        db, registration.user_id,
        "Registration Rejected",
        f"Your registration for '{event.title}' was not approved. Contact the event coordinator for details."
    )

    return registration


def register_team(db: Session, event_id: int, leader_id: int, team_name: str, member_emails: list, project_idea: str = None):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    settings = _registration_deadline_check(db, event)

    all_user_ids = [leader_id]
    for email in member_emails:
        member = db.query(User).filter(User.email == email).first()
        if not member:
            raise HTTPException(status_code=404, detail=f"No student found with email: {email}")
        if member.id not in all_user_ids:
            all_user_ids.append(member.id)

    if len(all_user_ids) > settings.max_team_size:
        raise HTTPException(status_code=400, detail=f"Team size cannot exceed {settings.max_team_size} members.")

    if event.max_participants is not None:
        already_registered_ids = set(
            r.user_id for r in db.query(Registration).filter(Registration.event_id == event_id).all()
        )
        new_count = len([uid for uid in all_user_ids if uid not in already_registered_ids])
        current_count = len(already_registered_ids)
        if current_count + new_count > event.max_participants:
            raise HTTPException(status_code=400, detail="Not enough slots left for this team.")

    new_team = Team(event_id=event_id, team_name=team_name, project_idea=project_idea, created_by=leader_id)
    db.add(new_team)
    db.commit()
    db.refresh(new_team)

    members_info = []
    for uid in all_user_ids:
        existing = db.query(Registration).filter(
            Registration.event_id == event_id,
            Registration.user_id == uid
        ).first()

        if existing:
            existing.team_id = new_team.id
            reg = existing
        else:
            reg = Registration(event_id=event_id, user_id=uid, team_id=new_team.id)
            db.add(reg)
            db.commit()
            db.refresh(reg)

        student = db.query(User).filter(User.id == uid).first()
        members_info.append({
            "student_name": student.full_name,
            "student_email": student.email,
            "qr_code": reg.qr_code,
        })

    db.commit()

    return {
        "team_id": new_team.id,
        "team_name": new_team.team_name,
        "project_idea": new_team.project_idea,
        "event_id": event_id,
        "members": members_info,
    }


def get_my_team(db: Session, event_id: int, user_id: int):
    registration = db.query(Registration).filter(
        Registration.event_id == event_id,
        Registration.user_id == user_id
    ).first()

    if not registration or not registration.team_id:
        return None

    team = db.query(Team).filter(Team.id == registration.team_id).first()
    team_registrations = db.query(Registration).filter(Registration.team_id == team.id).all()

    members_info = []
    for reg in team_registrations:
        student = db.query(User).filter(User.id == reg.user_id).first()
        members_info.append({
            "student_name": student.full_name,
            "student_email": student.email,
            "qr_code": reg.qr_code,
        })

    return {
        "team_id": team.id,
        "team_name": team.team_name,
        "event_id": event_id,
        "members": members_info,
    }


def refresh_qr_code(db: Session, registration_id: int, user_id: int):
    registration = db.query(Registration).filter(
        Registration.id == registration_id,
        Registration.user_id == user_id
    ).first()

    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")

    if registration.is_attended:
        raise HTTPException(status_code=400, detail="Already checked in — code can't be refreshed")

    registration.qr_code = str(uuid.uuid4())
    db.commit()
    db.refresh(registration)

    return {"registration_id": registration.id, "qr_code": registration.qr_code}