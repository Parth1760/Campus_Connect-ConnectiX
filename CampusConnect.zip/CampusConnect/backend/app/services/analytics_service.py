from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.event import Event
from app.models.registration import Registration
from app.models.user import User
from datetime import datetime, timedelta, timezone
from collections import defaultdict
from fastapi import HTTPException
from app.models.score import Score
from app.models.team import Team
from app.models.volunteer_assignment import VolunteerAssignment
from app.models.feedback import Feedback


def get_event_analytics(db: Session, event_id: int):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    registrations = db.query(Registration).filter(Registration.event_id == event_id).all()

    total_registered = len(registrations)
    total_attended = len([r for r in registrations if r.is_attended])
    attendance_rate = round((total_attended / total_registered * 100), 1) if total_registered > 0 else 0.0

    dept_map = {}
    for reg in registrations:
        student = db.query(User).filter(User.id == reg.user_id).first()
        dept = (student.department if student and student.department else "Unknown")
        if dept not in dept_map:
            dept_map[dept] = {"registered": 0, "attended": 0}
        dept_map[dept]["registered"] += 1
        if reg.is_attended:
            dept_map[dept]["attended"] += 1

    department_breakdown = [
        {"department": dept, "registered_count": stats["registered"], "attended_count": stats["attended"]}
        for dept, stats in dept_map.items()
    ]
    department_breakdown.sort(key=lambda x: x["registered_count"], reverse=True)

    return {
        "event_id": event.id,
        "event_title": event.title,
        "total_registered": total_registered,
        "total_attended": total_attended,
        "attendance_rate": attendance_rate,
        "department_breakdown": department_breakdown,
    }


def get_overview_analytics(db: Session):
    events = db.query(Event).all()

    events_summary = []
    total_registrations = 0
    total_attendances = 0

    for event in events:
        registrations = db.query(Registration).filter(Registration.event_id == event.id).all()
        registered_count = len(registrations)
        attended_count = len([r for r in registrations if r.is_attended])

        total_registrations += registered_count
        total_attendances += attended_count

        events_summary.append({
            "event_id": event.id,
            "event_title": event.title,
            "registered_count": registered_count,
            "attended_count": attended_count,
        })

    events_summary.sort(key=lambda x: x["registered_count"], reverse=True)

    return {
        "total_events": len(events),
        "total_registrations": total_registrations,
        "total_attendances": total_attendances,
        "events_summary": events_summary,
    }


def get_admin_analytics_portal(db: Session):
    now = datetime.now(timezone.utc)
    thirty_days_ago = now - timedelta(days=30)

    all_users = db.query(User).all()
    new_users_30d = 0
    for u in all_users:
        created = u.created_at
        if created and created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        if created and created >= thirty_days_ago:
            new_users_30d += 1

    all_registrations = db.query(Registration).all()
    total_reg = len(all_registrations)
    total_attended = len([r for r in all_registrations if r.is_attended])
    avg_attendance = round((total_attended / total_reg * 100), 1) if total_reg > 0 else 0.0

    all_events = db.query(Event).all()
    events_held_30d = 0
    for e in all_events:
        d = e.event_date
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        if thirty_days_ago <= d <= now:
            events_held_30d += 1

    certs_issued = len([r for r in all_registrations if r.certificate_id])

    week_buckets = defaultdict(int)
    for r in all_registrations:
        if r.registered_at:
            reg_date = r.registered_at
            if reg_date.tzinfo is None:
                reg_date = reg_date.replace(tzinfo=timezone.utc)
            weeks_ago = (now - reg_date).days // 7
            if 0 <= weeks_ago < 7:
                week_buckets[weeks_ago] += 1

    registrations_trend = []
    for i in range(6, -1, -1):
        registrations_trend.append({"week_label": f"W{7 - i}", "count": week_buckets.get(i, 0)})

    category_counts = defaultdict(int)
    for e in all_events:
        cat = e.category or "Uncategorized"
        reg_count = len([r for r in all_registrations if r.event_id == e.id])
        category_counts[cat] += reg_count

    popular_categories = [{"category": k, "count": v} for k, v in category_counts.items() if v > 0]
    popular_categories.sort(key=lambda x: x["count"], reverse=True)

    return {
        "new_users_30d": new_users_30d,
        "avg_attendance": avg_attendance,
        "events_held_30d": events_held_30d,
        "certs_issued": certs_issued,
        "registrations_trend": registrations_trend,
        "popular_categories": popular_categories[:6],
    }


# ---------- Faculty ----------

def get_faculty_analytics_list(db: Session):
    faculty = db.query(User).filter(User.role == "faculty").all()
    result = []
    for f in faculty:
        events = db.query(Event).filter(Event.created_by == f.id).all()
        total_registrations = 0
        total_attended = 0
        feedbacks = []
        for e in events:
            regs = db.query(Registration).filter(Registration.event_id == e.id).all()
            total_registrations += len(regs)
            total_attended += len([r for r in regs if r.is_attended])
            feedbacks += db.query(Feedback).filter(Feedback.event_id == e.id).all()

        attendance_rate = round((total_attended / total_registrations * 100), 1) if total_registrations > 0 else 0.0
        avg_rating = round(sum(fb.rating for fb in feedbacks) / len(feedbacks), 1) if feedbacks else 0.0

        result.append({
            "id": f.id, "full_name": f.full_name, "email": f.email, "department": f.department,
            "total_events": len(events), "total_registrations": total_registrations,
            "total_attended": total_attended, "attendance_rate": attendance_rate, "avg_rating": avg_rating,
        })
    result.sort(key=lambda x: x["total_registrations"], reverse=True)
    return result


def get_faculty_analytics_detail(db: Session, faculty_id: int):
    f = db.query(User).filter(User.id == faculty_id, User.role == "faculty").first()
    if not f:
        raise HTTPException(status_code=404, detail="Faculty not found")

    events = db.query(Event).filter(Event.created_by == f.id).order_by(Event.event_date.desc()).all()
    event_details = []
    total_registrations = 0
    total_attended = 0
    all_feedbacks = []
    for e in events:
        regs = db.query(Registration).filter(Registration.event_id == e.id).all()
        attended = len([r for r in regs if r.is_attended])
        total_registrations += len(regs)
        total_attended += attended
        all_feedbacks += db.query(Feedback).filter(Feedback.event_id == e.id).all()
        event_details.append({
            "event_id": e.id, "title": e.title, "event_date": e.event_date,
            "registration_count": len(regs), "attended_count": attended,
        })

    attendance_rate = round((total_attended / total_registrations * 100), 1) if total_registrations > 0 else 0.0
    avg_rating = round(sum(fb.rating for fb in all_feedbacks) / len(all_feedbacks), 1) if all_feedbacks else 0.0

    return {
        "id": f.id, "full_name": f.full_name, "email": f.email, "department": f.department,
        "total_events": len(events), "total_registrations": total_registrations,
        "total_attended": total_attended, "attendance_rate": attendance_rate, "avg_rating": avg_rating,
        "events": event_details,
    }


# ---------- Volunteer ----------

def get_volunteer_analytics_list(db: Session):
    volunteers = db.query(User).filter(User.role == "volunteer").all()
    result = []
    for v in volunteers:
        checkins = db.query(Registration).filter(Registration.checked_in_by == v.id).all()
        result.append({
            "id": v.id, "full_name": v.full_name, "email": v.email,
            "total_checkins": len(checkins),
            "events_worked": len(set(r.event_id for r in checkins)),
        })
    result.sort(key=lambda x: x["total_checkins"], reverse=True)
    return result


def get_volunteer_analytics_detail(db: Session, volunteer_id: int):
    v = db.query(User).filter(User.id == volunteer_id, User.role == "volunteer").first()
    if not v:
        raise HTTPException(status_code=404, detail="Volunteer not found")

    checkins = db.query(Registration).filter(Registration.checked_in_by == v.id).order_by(Registration.checked_in_at.desc()).all()

    recent = []
    for r in checkins[:50]:
        student = db.query(User).filter(User.id == r.user_id).first()
        event = db.query(Event).filter(Event.id == r.event_id).first()
        recent.append({
            "student_name": student.full_name if student else "Unknown",
            "event_title": event.title if event else "Unknown",
            "checked_in_at": r.checked_in_at,
        })

    assignments = db.query(VolunteerAssignment).filter(VolunteerAssignment.volunteer_id == v.id).all()
    assigned_events = []
    for a in assignments:
        e = db.query(Event).filter(Event.id == a.event_id).first()
        if e:
            assigned_events.append(e.title)

    return {
        "id": v.id, "full_name": v.full_name, "email": v.email,
        "total_checkins": len(checkins),
        "events_worked": len(set(r.event_id for r in checkins)),
        "assigned_events": assigned_events,
        "recent_checkins": recent,
    }


# ---------- Judge ----------

def get_judge_analytics_list(db: Session):
    judges = db.query(User).filter(User.role == "judge").all()
    result = []
    for j in judges:
        scores = db.query(Score).filter(Score.judge_id == j.id).all()
        avg = round(sum(s.score for s in scores) / len(scores), 1) if scores else 0.0
        result.append({
            "id": j.id, "full_name": j.full_name, "email": j.email,
            "total_evaluations": len(scores), "avg_score_given": avg,
            "events_judged": len(set(s.event_id for s in scores)),
        })
    result.sort(key=lambda x: x["total_evaluations"], reverse=True)
    return result


def get_judge_analytics_detail(db: Session, judge_id: int):
    j = db.query(User).filter(User.id == judge_id, User.role == "judge").first()
    if not j:
        raise HTTPException(status_code=404, detail="Judge not found")

    scores = db.query(Score).filter(Score.judge_id == j.id).order_by(Score.created_at.desc()).all()

    evaluations = []
    for s in scores:
        event = db.query(Event).filter(Event.id == s.event_id).first()
        team_name = None
        if s.team_id:
            team = db.query(Team).filter(Team.id == s.team_id).first()
            team_name = team.team_name if team else None
        elif s.registration_id:
            reg = db.query(Registration).filter(Registration.id == s.registration_id).first()
            if reg:
                student = db.query(User).filter(User.id == reg.user_id).first()
                team_name = student.full_name if student else None
        evaluations.append({
            "team_name": team_name or "Unknown",
            "event_title": event.title if event else "Unknown",
            "score": s.score,
        })

    avg = round(sum(s.score for s in scores) / len(scores), 1) if scores else 0.0

    return {
        "id": j.id, "full_name": j.full_name, "email": j.email,
        "total_evaluations": len(scores), "avg_score_given": avg,
        "events_judged": len(set(s.event_id for s in scores)),
        "evaluations": evaluations,
    }