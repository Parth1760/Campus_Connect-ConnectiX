from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.score import Score
from app.models.registration import Registration
from app.models.user import User
from app.services.notification_service import create_notification
from datetime import datetime, timezone
from app.models.team import Team
from app.models.event import Event


def get_participants_for_event(db: Session, event_id: int, judge_id: int):
    registrations = db.query(Registration).filter(
        Registration.event_id == event_id,
        Registration.is_attended == True
    ).all()

    result = []
    for reg in registrations:
        student = db.query(User).filter(User.id == reg.user_id).first()
        existing_score = db.query(Score).filter(
            Score.registration_id == reg.id,
            Score.judge_id == judge_id
        ).first()

        result.append({
            "registration_id": reg.id,
            "student_id": reg.user_id,
            "student_name": student.full_name if student else "Unknown",
            "student_email": student.email if student else "",
            "is_attended": reg.is_attended,
            "my_score": existing_score.score if existing_score else None,
            "my_remarks": existing_score.remarks if existing_score else None,
        })
    return result


def submit_score(db: Session, event_id: int, judge_id: int, score_data):
    registration = db.query(Registration).filter(
        Registration.id == score_data.registration_id
    ).first()

    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")

    if registration.event_id != event_id:
        raise HTTPException(status_code=400, detail="Registration does not belong to this event")

    existing = db.query(Score).filter(
        Score.registration_id == score_data.registration_id,
        Score.judge_id == judge_id
    ).first()

    if existing:
        existing.score = score_data.score
        existing.remarks = score_data.remarks
        db.commit()
        db.refresh(existing)
        return existing

    new_score = Score(
        event_id=event_id,
        registration_id=score_data.registration_id,
        judge_id=judge_id,
        score=score_data.score,
        remarks=score_data.remarks,
    )
    db.add(new_score)
    db.commit()
    db.refresh(new_score)

    registration = db.query(Registration).filter(Registration.id == score_data.registration_id).first()
    create_notification(
        db, registration.user_id,
        "Score Received",
        f"You received a score of {score_data.score} for your participation."
    )

    return new_score

def get_leaderboard(db: Session, event_id: int):
    registrations = db.query(Registration).filter(
        Registration.event_id == event_id,
        Registration.is_attended == True
    ).all()

    entries = []
    for reg in registrations:
        scores = db.query(Score).filter(Score.registration_id == reg.id).all()
        if not scores:
            continue
        student = db.query(User).filter(User.id == reg.user_id).first()
        avg = sum(s.score for s in scores) / len(scores)
        entries.append({
            "student_name": student.full_name if student else "Unknown",
            "average_score": round(avg, 1),
            "total_judges": len(scores),
        })

    entries.sort(key=lambda x: x["average_score"], reverse=True)

    result = []
    for idx, entry in enumerate(entries):
        result.append({"rank": idx + 1, **entry})
    return result


def get_teams_for_judging(db: Session, event_id: int, judge_id: int):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    teams = db.query(Team).filter(Team.event_id == event_id).all()

    result = []
    for team in teams:
        member_count = db.query(Registration).filter(Registration.team_id == team.id).count()
        existing = db.query(Score).filter(Score.team_id == team.id, Score.judge_id == judge_id).first()

        result.append({
            "team_id": team.id,
            "team_name": team.team_name,
            "project_idea": team.project_idea,
            "member_count": member_count,
            "status": "evaluated" if existing else "pending",
            "my_score": existing.score if existing else None,
            "my_innovation": existing.innovation if existing else None,
            "my_technical_implementation": existing.technical_implementation if existing else None,
            "my_presentation": existing.presentation if existing else None,
            "my_problem_solving": existing.problem_solving if existing else None,
            "my_remarks": existing.remarks if existing else None,
        })
    return result


def submit_team_score(db: Session, event_id: int, judge_id: int, data):
    team = db.query(Team).filter(Team.id == data.team_id, Team.event_id == event_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Team not found for this event")

    total = data.innovation + data.technical_implementation + data.presentation + data.problem_solving

    existing = db.query(Score).filter(Score.team_id == team.id, Score.judge_id == judge_id).first()

    if existing:
        existing.innovation = data.innovation
        existing.technical_implementation = data.technical_implementation
        existing.presentation = data.presentation
        existing.problem_solving = data.problem_solving
        existing.score = total
        existing.remarks = data.remarks
        db.commit()
        db.refresh(existing)
        return existing

    new_score = Score(
        event_id=event_id,
        team_id=team.id,
        judge_id=judge_id,
        innovation=data.innovation,
        technical_implementation=data.technical_implementation,
        presentation=data.presentation,
        problem_solving=data.problem_solving,
        score=total,
        remarks=data.remarks,
    )
    db.add(new_score)
    db.commit()
    db.refresh(new_score)

    create_notification(
        db, team.created_by,
        "Score Received",
        f"Your team '{team.team_name}' received a score of {total}/100."
    )

    return new_score


def get_team_leaderboard(db: Session, event_id: int):
    teams = db.query(Team).filter(Team.event_id == event_id).all()

    entries = []
    for team in teams:
        scores = db.query(Score).filter(Score.team_id == team.id).all()
        if not scores:
            continue
        avg = sum(s.score for s in scores) / len(scores)
        entries.append({
            "team_name": team.team_name,
            "average_score": round(avg, 1),
            "total_judges": len(scores),
        })

    entries.sort(key=lambda x: x["average_score"], reverse=True)

    result = []
    for idx, entry in enumerate(entries):
        result.append({"rank": idx + 1, **entry})
    return result


def get_judge_dashboard(db: Session, judge_id: int):
    all_teams = db.query(Team).all()
    total_teams = len(all_teams)

    my_team_scores = db.query(Score).filter(Score.judge_id == judge_id, Score.team_id.isnot(None)).all()
    teams_evaluated = len(set(s.team_id for s in my_team_scores))
    avg_score_given = round(sum(s.score for s in my_team_scores) / len(my_team_scores), 1) if my_team_scores else 0.0

    now = datetime.now(timezone.utc)
    all_events = db.query(Event).order_by(Event.event_date.asc()).all()

    def event_date_aware(event):
        d = event.event_date
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)

    current_event = None
    for event in all_events:
        if db.query(Team).filter(Team.event_id == event.id).count() == 0:
            continue
        if event_date_aware(event).date() == now.date():
            current_event = event
            break
    if current_event is None:
        for event in all_events:
            if db.query(Team).filter(Team.event_id == event.id).count() == 0:
                continue
            if event_date_aware(event) >= now:
                current_event = event
                break

    current_assignment = None
    if current_event:
        event_teams = db.query(Team).filter(Team.event_id == current_event.id).all()
        total = len(event_teams)
        team_ids = [t.id for t in event_teams]
        evaluated = db.query(Score).filter(Score.judge_id == judge_id, Score.team_id.in_(team_ids)).count() if team_ids else 0
        percent = round((evaluated / total * 100), 0) if total > 0 else 0

        current_assignment = {
            "event_id": current_event.id,
            "event_title": current_event.title,
            "venue": current_event.venue,
            "total_teams": total,
            "evaluated_count": evaluated,
            "percent_evaluated": percent,
            "remaining": total - evaluated,
        }

    upcoming = []
    for event in all_events:
        if current_event and event.id == current_event.id:
            continue
        if db.query(Team).filter(Team.event_id == event.id).count() == 0:
            continue
        if event_date_aware(event) >= now:
            upcoming.append({"event_id": event.id, "title": event.title, "event_date": event.event_date})
        if len(upcoming) >= 3:
            break

    return {
        "teams_evaluated": teams_evaluated,
        "total_teams": total_teams,
        "avg_score_given": avg_score_given,
        "current_assignment": current_assignment,
        "upcoming": upcoming,
    }