import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv

load_dotenv()


def send_reset_email(to_email: str, reset_link: str):
    sender_email = os.getenv("EMAIL_ADDRESS")
    sender_password = os.getenv("EMAIL_APP_PASSWORD")

    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = to_email
    msg["Subject"] = "Reset Your CampusConnect Password"

    body = f"""Hi,

You requested to reset your CampusConnect password. Click the link below to set a new password:

{reset_link}

This link will expire in 30 minutes. If you didn't request this, please ignore this email.

- CampusConnect Team
"""
    msg.attach(MIMEText(body, "plain"))

    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, to_email, msg.as_string())


def send_otp_email(to_email: str, otp_code: str):
    sender_email = os.getenv("EMAIL_ADDRESS")
    sender_password = os.getenv("EMAIL_APP_PASSWORD")

    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = to_email
    msg["Subject"] = "Verify Your CampusConnect Account"

    body = f"""Hi,

Your CampusConnect verification code is:

{otp_code}

This code will expire in 10 minutes. If you didn't request this, please ignore this email.

- CampusConnect Team
"""
    msg.attach(MIMEText(body, "plain"))

    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, to_email, msg.as_string())


def send_staff_invite_email(to_email: str, role: str, temp_password: str):
    sender_email = os.getenv("EMAIL_ADDRESS")
    sender_password = os.getenv("EMAIL_APP_PASSWORD")

    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = to_email
    msg["Subject"] = f"Your CampusConnect {role.capitalize()} Account"

    body = f"""Hi,

An administrator has created a CampusConnect {role} account for you.

Login Email: {to_email}
Temporary Password: {temp_password}

Please log in and change your password immediately from Settings.

- CampusConnect Team
"""
    msg.attach(MIMEText(body, "plain"))

    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, to_email, msg.as_string())