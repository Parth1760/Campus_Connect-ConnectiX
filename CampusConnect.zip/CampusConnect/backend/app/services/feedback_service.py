from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.feedback import Feedback
from app.models.registration import Registration
from app.models.event import Event


def submit_feedback(db: Session, event_id: int, user_id: int, data):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    registration = db.query(Registration).filter(
        Registration.event_id == event_id,
        Registration.user_id == user_id
    ).first()
    if not registration or not registration.is_attended:
        raise HTTPException(status_code=400, detail="Only attended participants can give feedback")

    existing = db.query(Feedback).filter(
        Feedback.event_id == event_id,
        Feedback.user_id == user_id
    ).first()

    if existing:
        existing.rating = data.rating
        existing.comment = data.comment
        db.commit()
        db.refresh(existing)
        return existing

    new_feedback = Feedback(event_id=event_id, user_id=user_id, rating=data.rating, comment=data.comment)
    db.add(new_feedback)
    db.commit()
    db.refresh(new_feedback)
    return new_feedback


def get_my_feedback(db: Session, event_id: int, user_id: int):
    return db.query(Feedback).filter(
        Feedback.event_id == event_id,
        Feedback.user_id == user_id
    ).first()