from sqlalchemy.orm import Session
from datetime import datetime, timezone

from app.models.user import User
from app.models.event import Event
from app.models.registration import Registration
import secrets
import string
from fastapi import HTTPException
from app.utils.security import hash_password
from app.services.email_service import send_staff_invite_email


def get_admin_dashboard(db: Session):
    now = datetime.now(timezone.utc)

    total_users = db.query(User).count()
    total_events = db.query(Event).count()
    total_registrations = db.query(Registration).count()
    total_attended = db.query(Registration).filter(Registration.is_attended == True).count()
    attendance_rate = round((total_attended / total_registrations * 100), 1) if total_registrations > 0 else 0.0

    all_events = db.query(Event).all()
    active_events = 0
    for event in all_events:
        d = event.event_date
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        if d >= now:
            active_events += 1

    recent_users = db.query(User).order_by(User.created_at.desc()).limit(5).all()
    recent_events = db.query(Event).order_by(Event.created_at.desc()).limit(5).all()

    activity = []
    for u in recent_users:
        activity.append({
            "type": "user_signup",
            "message": f"New {u.role} registration: {u.full_name}",
            "timestamp": u.created_at,
        })
    for e in recent_events:
        activity.append({
            "type": "event_created",
            "message": f"Event created: {e.title}",
            "timestamp": e.created_at,
        })

    activity.sort(key=lambda x: x["timestamp"], reverse=True)
    activity = activity[:8]

    return {
        "total_users": total_users,
        "total_events": total_events,
        "active_events": active_events,
        "total_registrations": total_registrations,
        "attendance_rate": attendance_rate,
        "recent_activity": activity,
    }


VALID_STAFF_ROLES = ["faculty", "volunteer", "judge", "admin"]


def _generate_temp_password(length: int = 10) -> str:
    chars = string.ascii_letters + string.digits
    return "".join(secrets.choice(chars) for _ in range(length))


def create_staff_account(db: Session, data):
    if data.role not in VALID_STAFF_ROLES:
        raise HTTPException(status_code=400, detail=f"Role must be one of: {', '.join(VALID_STAFF_ROLES)}")
    

    existing_email = db.query(User).filter(User.email == data.email).first()
    if existing_email:
        raise HTTPException(status_code=400, detail="Email already registered")

    existing_phone = db.query(User).filter(User.phone == data.phone).first()
    if existing_phone:
        raise HTTPException(status_code=400, detail="Phone number already registered")

    temp_password = _generate_temp_password()

    new_user = User(
        full_name=data.full_name,
        email=data.email,
        phone=data.phone,
        password=hash_password(temp_password),
        role=data.role,
        college=data.college,
        department=data.department,
        is_active=True,
        is_verified=True,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    send_staff_invite_email(data.email, data.role, temp_password)

    return {
        "id": new_user.id,
        "full_name": new_user.full_name,
        "email": new_user.email,
        "role": new_user.role,
        "message": f"{data.role.capitalize()} account created and invite emailed successfully.",
    }