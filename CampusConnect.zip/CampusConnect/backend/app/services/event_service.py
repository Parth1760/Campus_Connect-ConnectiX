from typing import Optional

from sqlalchemy.orm import Session
from app.models.event import Event
from fastapi import HTTPException
from app.models.registration import Registration
from datetime import datetime, timedelta, timezone
from collections import defaultdict
from app.models.feedback import Feedback
from app.models.user import User
from app.services.notification_service import create_notification
from app.models.notification import Notification


def create_event(db: Session, event_data, user_id: int):
    new_event = Event(
        title=event_data.title,
        description=event_data.description,
        venue=event_data.venue,
        event_date=event_data.event_date,
        category=event_data.category,
        max_participants=event_data.max_participants,
        allow_team_registration=event_data.allow_team_registration,
        banner_url=event_data.banner_url,
        created_by=user_id
    )
    db.add(new_event)
    db.commit()
    db.refresh(new_event)

    students = db.query(User).filter(User.role == "student", User.is_active == True).all()
    for student in students:
        notification = Notification(
            user_id=student.id,
            title="New Event Published",
            message=f"'{new_event.title}' is now open for registration. Check it out!",
        )
        db.add(notification)
    db.commit()

    return new_event


def get_all_events(db: Session):
    events = db.query(Event).all()
    result = []
    for event in events:
        reg_count = db.query(Registration).filter(Registration.event_id == event.id).count()
        result.append({
            "id": event.id,
            "title": event.title,
            "description": event.description,
            "venue": event.venue,
            "event_date": event.event_date,
            "created_by": event.created_by,
            "created_at": event.created_at,
            "registration_count": reg_count,
            "category": event.category,
            "max_participants": event.max_participants,
            "allow_team_registration": event.allow_team_registration,
            "banner_url": event.banner_url,
            "coordinator_name": (db.query(User).filter(User.id == event.created_by).first().full_name
                                  if db.query(User).filter(User.id == event.created_by).first() else None),
        })
    return result


def get_event_by_id(db: Session, event_id: int):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        return None
    reg_count = db.query(Registration).filter(Registration.event_id == event_id).count()
    coordinator = db.query(User).filter(User.id == event.created_by).first()
    return {
        "id": event.id,
        "title": event.title,
        "description": event.description,
        "venue": event.venue,
        "event_date": event.event_date,
        "created_by": event.created_by,
        "created_at": event.created_at,
        "registration_count": reg_count,
        "category": event.category,
        "max_participants": event.max_participants,
        "allow_team_registration": event.allow_team_registration,
        "banner_url": event.banner_url,
        "coordinator_name": coordinator.full_name if coordinator else None,
    }


def update_event(db: Session, event_id: int, event_data, current_user):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    if current_user.role != "admin" and event.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="You can only edit your own events")

    if event_data.title is not None:
        event.title = event_data.title
    if event_data.description is not None:
        event.description = event_data.description
    if event_data.venue is not None:
        event.venue = event_data.venue
    if event_data.event_date is not None:
        event.event_date = event_data.event_date
    if event_data.category is not None:
        event.category = event_data.category
    if event_data.max_participants is not None:
        event.max_participants = event_data.max_participants
    if event_data.allow_team_registration is not None:
        event.allow_team_registration = event_data.allow_team_registration
    if event_data.banner_url is not None:
        event.banner_url = event_data.banner_url

    db.commit()
    db.refresh(event)
    return event


def delete_event(db: Session, event_id: int, current_user):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    if current_user.role != "admin" and event.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="You can only delete your own events")

    db.delete(event)
    db.commit()
    return {"message": "Event deleted successfully"}


def get_faculty_dashboard(db: Session, faculty_id: int):
    events = db.query(Event).filter(Event.created_by == faculty_id).all()

    total_events = len(events)
    total_registrations = 0
    total_attended = 0
    managed_events = []

    for event in events:
        registrations = db.query(Registration).filter(Registration.event_id == event.id).all()
        reg_count = len(registrations)
        attended_count = len([r for r in registrations if r.is_attended])

        total_registrations += reg_count
        total_attended += attended_count

        status = "Active"
        managed_events.append({
            "id": event.id,
            "title": event.title,
            "event_date": event.event_date,
            "registration_count": reg_count,
            "status": status,
        })

    managed_events.sort(key=lambda x: x["event_date"], reverse=True)

    attendance_rate = round((total_attended / total_registrations * 100), 1) if total_registrations > 0 else 0.0

    return {
        "total_events": total_events,
        "active_events": total_events,
        "total_registrations": total_registrations,
        "attendance_rate": attendance_rate,
        "managed_events": managed_events,
    }

def get_event_analytics_detail(db: Session, event_id: int, current_user):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    if current_user.role != "admin" and event.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="You can only view analytics for your own events")

    registrations = db.query(Registration).filter(Registration.event_id == event_id).all()
    total_registered = len(registrations)
    total_attended = len([r for r in registrations if r.is_attended])
    attendance_rate = round((total_attended / total_registered * 100), 1) if total_registered > 0 else 0.0
    certs_issued = len([r for r in registrations if r.certificate_id])

    feedbacks = db.query(Feedback).filter(Feedback.event_id == event_id).all()
    avg_rating = round(sum(f.rating for f in feedbacks) / len(feedbacks), 1) if feedbacks else 0.0

    counts_by_date = defaultdict(int)
    for r in registrations:
        if r.registered_at:
            key = r.registered_at.date().isoformat()
            counts_by_date[key] += 1

    today = datetime.now(timezone.utc).date()
    daily_trend = []
    for i in range(6, -1, -1):
        d = today - timedelta(days=i)
        key = d.isoformat()
        daily_trend.append({"date": key, "count": counts_by_date.get(key, 0)})

    return {
        "event_id": event.id,
        "event_title": event.title,
        "total_registered": total_registered,
        "total_attended": total_attended,
        "attendance_rate": attendance_rate,
        "avg_rating": avg_rating,
        "certs_issued": certs_issued,
        "daily_trend": daily_trend,
    }