from sqlalchemy.orm import Session

from app.models.system_settings import SystemSettings


def get_settings(db: Session):
    settings = db.query(SystemSettings).first()
    if not settings:
        settings = SystemSettings()
        db.add(settings)
        db.commit()
        db.refresh(settings)
    return settings


def update_settings(db: Session, data):
    settings = get_settings(db)

    if data.app_name is not None:
        settings.app_name = data.app_name
    if data.default_language is not None:
        settings.default_language = data.default_language
    if data.timezone is not None:
        settings.timezone = data.timezone
    if data.max_team_size is not None:
        settings.max_team_size = data.max_team_size
    if data.registration_buffer_hours is not None:
        settings.registration_buffer_hours = data.registration_buffer_hours
    if data.session_timeout_minutes is not None:
        settings.session_timeout_minutes = data.session_timeout_minutes
    if data.two_factor_enabled is not None:
        settings.two_factor_enabled = data.two_factor_enabled

    db.commit()
    db.refresh(settings)
    return settings