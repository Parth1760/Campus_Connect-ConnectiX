from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.password_reset import PasswordReset
from app.models.user import User
from app.utils.security import hash_password
from app.services.email_service import send_reset_email

RESET_LINK_BASE = "http://127.0.0.1:8000"   # ← Put your actual LAN IP here
TOKEN_EXPIRY_MINUTES = 30


def request_password_reset(db: Session, email: str):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        return {"message": "If this email is registered, a reset link has been sent."}

    reset_entry = PasswordReset(email=email)
    db.add(reset_entry)
    db.commit()
    db.refresh(reset_entry)

    reset_link = f"{RESET_LINK_BASE}/auth/reset-password-page?token={reset_entry.token}"
    send_reset_email(email, reset_link)

    return {"message": "If this email is registered, a reset link has been sent."}


def reset_password(db: Session, token: str, new_password: str):
    reset_entry = db.query(PasswordReset).filter(PasswordReset.token == token).first()

    if not reset_entry:
        raise HTTPException(status_code=400, detail="Invalid or expired reset link")

    if reset_entry.is_used:
        raise HTTPException(status_code=400, detail="This reset link has already been used")

    expiry_time = reset_entry.created_at + timedelta(minutes=TOKEN_EXPIRY_MINUTES)
    if datetime.now(timezone.utc) > expiry_time.replace(tzinfo=timezone.utc):
        raise HTTPException(status_code=400, detail="This reset link has expired")

    user = db.query(User).filter(User.email == reset_entry.email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.password = hash_password(new_password)
    reset_entry.is_used = True
    db.commit()

    return {"message": "Password reset successful"}