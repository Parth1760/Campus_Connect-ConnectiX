from fastapi import FastAPI
from app.routers.auth import router as auth_router
from app.routers import analytics

from app.database import Base, engine
from app.models.user import User
from app.routers import event
from app.routers import registration
from app.routers import score
from app.routers import notification
from app.routers import team
from app.routers import feedback
from app.routers import certificate
from app.routers import volunteer
from app.routers import admin



Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="CampusConnect API",
    version="1.0.0",
    description="Backend API for CampusConnect"
)

app.include_router(auth_router),
app.include_router(registration.router)
app.include_router(score.router)
app.include_router(notification.router)
app.include_router(analytics.router)
app.include_router(event.router)
app.include_router(team.router)
app.include_router(feedback.router)
app.include_router(certificate.router)
app.include_router(volunteer.router)
app.include_router(admin.router)
@app.get("/")
def home():
    return {
        "message": "CampusConnect Backend Running Successfully"
    }
