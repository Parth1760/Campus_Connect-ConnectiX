from app.database import SessionLocal
from app.models.user import User
from app.models.event import Event
from app.models.volunteer_assignment import VolunteerAssignment

db = SessionLocal()

volunteers = db.query(User).filter(User.role == "volunteer").order_by(User.id).all()
events = db.query(Event).order_by(Event.event_date.asc()).all()

for i, v in enumerate(volunteers):
    event = events[i % len(events)]
    existing = db.query(VolunteerAssignment).filter_by(volunteer_id=v.id, event_id=event.id).first()
    if not existing:
        db.add(VolunteerAssignment(volunteer_id=v.id, event_id=event.id))

db.commit()
print(f"Assigned {len(volunteers)} volunteers to events.")