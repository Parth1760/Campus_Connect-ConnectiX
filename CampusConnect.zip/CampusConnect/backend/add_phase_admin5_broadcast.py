from app.database import Base, engine
from app.models.user import User
from app.models.broadcast import Broadcast
from sqlalchemy import text

print("Creating broadcasts table...")
Base.metadata.create_all(bind=engine)

try:
    with engine.connect() as conn:
        conn.execute(text("ALTER TABLE notifications ADD COLUMN broadcast_id INT NULL"))
        conn.commit()
    print("broadcast_id column added to notifications!")
except Exception as e:
    print(f"Note: {e}")

print("Done!")