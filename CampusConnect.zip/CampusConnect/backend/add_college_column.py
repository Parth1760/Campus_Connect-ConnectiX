from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE users ADD COLUMN college VARCHAR(150) NULL"))
    conn.commit()

print("College column added successfully!")