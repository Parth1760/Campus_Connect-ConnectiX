from app.database import Base, engine
from app.models.user import User
from app.models.event import Event
from app.models.system_settings import SystemSettings
from app.models.volunteer_assignment import VolunteerAssignment

print("Creating system_settings and volunteer_assignments tables...")
Base.metadata.create_all(bind=engine)
print("Done!")