from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE events ADD COLUMN allow_team_registration BOOLEAN DEFAULT TRUE"))
    conn.commit()

print("allow_team_registration column added to events!")