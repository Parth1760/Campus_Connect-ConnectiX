from app.utils.security import hash_password
from app.utils.security import verify_password

password = "Parth@123"

hashed_password = hash_password(password)

print("Original Password :", password)
print("Hashed Password   :", hashed_password)

print("\nVerification :", verify_password(password, hashed_password))