from app.database import engine
from sqlalchemy import text

TABLES = [
    "scores", "feedbacks", "notifications", "broadcasts", "registrations",
    "teams", "events", "password_resets", "email_verifications", "users",
]

with engine.connect() as conn:
    conn.execute(text("SET FOREIGN_KEY_CHECKS=0"))
    for t in TABLES:
        conn.execute(text(f"TRUNCATE TABLE {t}"))
    conn.execute(text("SET FOREIGN_KEY_CHECKS=1"))
    conn.commit()

print("All data wiped! Tables reset (IDs restart from 1).")