from datetime import datetime, timedelta, timezone
from app.database import SessionLocal
from app.models.user import User
from app.models.event import Event
from app.models.team import Team
from app.models.registration import Registration
from app.utils.security import hash_password

db = SessionLocal()

PASSWORD = "Test@123"

def make_user(full_name, email, role, **extra):
    u = User(
        full_name=full_name,
        email=email,
        phone=f"9{abs(hash(email)) % 900000000 + 100000000}",
        password=hash_password(PASSWORD),
        role=role,
        is_active=True,
        is_verified=True,
        **extra
    )
    db.add(u)
    return u

# ---------- ADMINS (6) ----------
admins = [
    make_user("Super Admin", "admin@admin.in", "admin"),
    make_user("Prof. Alok Sen", "alok.admin@test.in", "admin"),
    make_user("Amit Gada", "amit.gada@test.in", "admin"),
    make_user("Sunita Rao", "sunita.rao@test.in", "admin"),
    make_user("Deepak Shah", "deepak.shah@test.in", "admin"),
    make_user("Farah Khan", "farah.khan@test.in", "admin"),
]

# ---------- FACULTY (6) ----------
faculty_list = [
    make_user("Dr. Anita Kulkarni", "anita.k@faculty.in", "faculty", department="Computer Science", college="KJ Somaiya College of Engineering"),
    make_user("Prof. Ramesh Nair", "ramesh.nair@faculty.in", "faculty", department="Information Technology", college="KJ Somaiya College of Engineering"),
    make_user("Dr. Meera Iyer", "meera.iyer@faculty.in", "faculty", department="Electronics", college="KJ Somaiya College of Engineering"),
    make_user("Prof. Kavita Joshi", "kavita.joshi@faculty.in", "faculty", department="Computer Science", college="KJ Somaiya College of Engineering"),
    make_user("Dr. Sunil Verma", "sunil.verma@faculty.in", "faculty", department="Mechanical", college="KJ Somaiya College of Engineering"),
    make_user("Prof. Rina Shah", "rina.shah@faculty.in", "faculty", department="AI & Data Science", college="KJ Somaiya College of Engineering"),
]

# ---------- VOLUNTEERS (6) ----------
volunteers = [
    make_user("Rahul Sharma", "rahul.sharma@test.in", "volunteer"),
    make_user("Sneha Patil", "sneha.patil@test.in", "volunteer"),
    make_user("Aditya Verma", "aditya.verma@test.in", "volunteer"),
    make_user("Priya Desai", "priya.desai@test.in", "volunteer"),
    make_user("Karan Mehta", "karan.mehta@test.in", "volunteer"),
    make_user("Neha Kapoor", "neha.kapoor@test.in", "volunteer"),
]

# ---------- JUDGES (6) ----------
judges = [
    make_user("Prof. Mehta", "mehta.judge@test.in", "judge"),
    make_user("Dr. Rajesh Nair", "rajesh.nair@test.in", "judge"),
    make_user("Prof. Shalini Rao", "shalini.rao@test.in", "judge"),
    make_user("Dr. Vivek Kulkarni", "vivek.kulkarni@test.in", "judge"),
    make_user("Prof. Ananya Das", "ananya.das@test.in", "judge"),
    make_user("Dr. Sameer Khan", "sameer.khan@test.in", "judge"),
]

# ---------- STUDENTS (6) ----------
students = [
    make_user("Parth Sharma", "parth.sharma@test.in", "student", college="KJ Somaiya College of Engineering", department="Computer Science", year="3rd Year", enrollment_number="EN2024001"),
    make_user("Rohan Mehta", "rohan.mehta@test.in", "student", college="KJ Somaiya College of Engineering", department="Information Technology", year="2nd Year", enrollment_number="EN2024002"),
    make_user("Sanya Gupta", "sanya.gupta@test.in", "student", college="VJTI Mumbai", department="Computer Science", year="4th Year", enrollment_number="EN2024003"),
    make_user("Vikram Rao", "vikram.rao@test.in", "student", college="KJ Somaiya College of Engineering", department="Electronics", year="3rd Year", enrollment_number="EN2024004"),
    make_user("Isha Malhotra", "isha.malhotra@test.in", "student", college="IIT Bombay", department="Computer Science", year="2nd Year", enrollment_number="EN2024005"),
    make_user("Aryan Shah", "aryan.shah@test.in", "student", college="KJ Somaiya College of Engineering", department="AI & Data Science", year="1st Year", enrollment_number="EN2024006"),
]

db.commit()
for u in faculty_list + students:
    db.refresh(u)

main_faculty = faculty_list[0]
now = datetime.now(timezone.utc)

events_data = [
    {"title": "AI Innovate Hackathon 2026", "category": "Hackathon", "venue": "Main Auditorium", "days": 6,
     "description": "A 36-hour hackathon where teams build AI-powered solutions for real campus and community problems. Mentorship from industry experts, free meals, and prizes worth ₹1,00,000.",
     "max_participants": 120, "allow_team": True,
     "banner": "https://loremflickr.com/800/400/hackathon,coding/all?lock=1"},
    {"title": "Smart City Hack Fest", "category": "Hackathon", "venue": "Innovation Lab, Block C", "days": 12,
     "description": "Build IoT and smart-city solutions addressing traffic, waste management, and energy efficiency. Hardware kits provided to shortlisted teams.",
     "max_participants": 100, "allow_team": True,
     "banner": "https://loremflickr.com/800/400/hackathon,technology/all?lock=2"},
    {"title": "FinTech Blockchain Hackathon", "category": "Hackathon", "venue": "Seminar Hall A", "days": 20,
     "description": "Design and build innovative fintech and blockchain solutions. Panel of judges from leading banks and startups will evaluate live demos.",
     "max_participants": 90, "allow_team": True,
     "banner": "https://loremflickr.com/800/400/hackathon,blockchain/all?lock=3"},
    {"title": "Flutter & Firebase Bootcamp", "category": "Workshop", "venue": "Computer Lab 3", "days": 8,
     "description": "A hands-on 2-day workshop where you build a complete mobile app from scratch using Flutter and Firebase. Laptop required.",
     "max_participants": 50, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/workshop,mobile/all?lock=4"},
    {"title": "Machine Learning with Python", "category": "Workshop", "venue": "Computer Lab 1", "days": 15,
     "description": "An introduction to machine learning concepts with hands-on Python notebooks. Certificate of completion provided to all attendees.",
     "max_participants": 60, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/workshop,programming/all?lock=5"},
    {"title": "Cloud Computing with AWS", "category": "Workshop", "venue": "Computer Lab 2", "days": 22,
     "description": "Learn to deploy and scale real applications on AWS through guided hands-on labs. Basic programming knowledge recommended.",
     "max_participants": 45, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/workshop,cloud/all?lock=6"},
    {"title": "Future of Artificial Intelligence", "category": "Seminar", "venue": "Main Auditorium", "days": 5,
     "description": "An industry expert shares insights on emerging AI trends, ethical challenges, and career opportunities in the field.",
     "max_participants": 200, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/seminar,conference/all?lock=7"},
    {"title": "Cybersecurity in the Digital Age", "category": "Seminar", "venue": "Seminar Hall B", "days": 17,
     "description": "A guest lecture covering current cybersecurity threats, real-world breach case studies, and best practices for staying safe online.",
     "max_participants": 150, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/seminar,cybersecurity/all?lock=8"},
    {"title": "Entrepreneurship & Startups", "category": "Seminar", "venue": "Main Auditorium", "days": 25,
     "description": "Founders of early-stage startups share their journey, challenges, and lessons learned building a company from the ground up.",
     "max_participants": 180, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/seminar,startup/all?lock=9"},
    {"title": "Robotics Challenge 2026", "category": "Competition", "venue": "Sports Complex Arena", "days": 10,
     "description": "Teams design, build, and battle autonomous robots through a series of obstacle and combat rounds. Robot kits available for rent.",
     "max_participants": 80, "allow_team": True,
     "banner": "https://loremflickr.com/800/400/robotics,competition/all?lock=10"},
    {"title": "Competitive Programming Contest", "category": "Competition", "venue": "Computer Lab 1", "days": 18,
     "description": "An ICPC-style algorithmic programming contest. Solve the most problems correctly in the shortest time to top the leaderboard.",
     "max_participants": 100, "allow_team": True,
     "banner": "https://loremflickr.com/800/400/programming,contest/all?lock=11"},
    {"title": "UI/UX Design Sprint", "category": "Competition", "venue": "Design Studio", "days": 27,
     "description": "A 6-hour design competition — redesign a real app's user experience and pitch it to a panel of design professionals.",
     "max_participants": 60, "allow_team": True,
     "banner": "https://loremflickr.com/800/400/design,creative/all?lock=12"},
    {"title": "Careers in Data Science", "category": "Webinar", "venue": "Online", "days": 4,
     "description": "A live online session on breaking into data science — skills to learn, portfolio tips, and how to crack interviews at top companies.",
     "max_participants": 300, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/datascience,analytics/all?lock=13"},
    {"title": "Intro to Web3 & Blockchain", "category": "Webinar", "venue": "Online", "days": 14,
     "description": "A beginner-friendly live webinar covering blockchain fundamentals, smart contracts, and how Web3 is changing the internet.",
     "max_participants": 300, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/blockchain,crypto/all?lock=14"},
    {"title": "Resume & Interview Prep", "category": "Webinar", "venue": "Online", "days": 23,
     "description": "Recruiters share practical tips on building a standout resume and acing technical and HR interviews for tech roles.",
     "max_participants": 300, "allow_team": False,
     "banner": "https://loremflickr.com/800/400/interview,office/all?lock=15"},
]

created_events = []
for i, e in enumerate(events_data):
    event_date = (now + timedelta(days=e["days"])).replace(hour=10, minute=0, second=0, microsecond=0)
    event = Event(
        title=e["title"], description=e["description"], venue=e["venue"], category=e["category"],
        max_participants=e["max_participants"], allow_team_registration=e["allow_team"],
        event_date=event_date, banner_url=e["banner"],
        created_by=faculty_list[i % len(faculty_list)].id,
    )
    db.add(event)
    created_events.append(event)

db.commit()
for e in created_events:
    db.refresh(e)

hackathon = created_events[0]  # AI Innovate Hackathon 2026
contest = created_events[10]   # Competitive Programming Contest

# Individual registrations
for student in [students[0], students[1]]:
    reg = Registration(event_id=hackathon.id, user_id=student.id)
    db.add(reg)

reg2 = Registration(event_id=contest.id, user_id=students[5].id)
db.add(reg2)
db.commit()

# Team registration with project idea
leader = students[2]
team = Team(
    event_id=hackathon.id,
    team_name="Code Crusaders",
    project_idea="An AI-powered campus navigation and event recommendation app that helps students discover relevant events based on their interests and past attendance.",
    created_by=leader.id,
)
db.add(team)
db.commit()
db.refresh(team)

for member in [students[2], students[3], students[4]]:
    reg = Registration(event_id=hackathon.id, user_id=member.id, team_id=team.id)
    db.add(reg)
db.commit()

print(f"Seeded: {len(admins)} admins, {len(faculty_list)} faculty, {len(volunteers)} volunteers, {len(judges)} judges, {len(students)} students, {len(created_events)} events")
print(f"Demo team 'Code Crusaders' registered for '{hackathon.title}' with a project idea")
print(f"\nAll accounts password: {PASSWORD}")
print("Sample logins:")
print("  Admin:     admin@admin.in")
print("  Faculty:   anita.k@faculty.in")
print("  Volunteer: rahul.sharma@test.in")
print("  Judge:     mehta.judge@test.in")
print("  Student:   parth.sharma@test.in")