from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE registrations ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'approved'"))
    conn.commit()

print("status column added to registrations (existing rows set to 'approved')!")