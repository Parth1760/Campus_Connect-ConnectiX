from app.database import engine
from sqlalchemy import text

with engine.connect() as conn:
    conn.execute(text("ALTER TABLE events ADD COLUMN banner_url VARCHAR(500) NULL"))
    conn.commit()

print("banner_url column added to events!")